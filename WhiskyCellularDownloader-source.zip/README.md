# Whisky LTE Downloader v0.5

v0.5 is a performance-focused update for the 333,313-URL Whiskybase image list.

## Why v0.4 was slow

The v0.4 log showed roughly 2–3 seconds per image because every queue item did a full top-level WebView navigation:

1. `loadUrl()`
2. page start / page finish
3. 650 ms inspection delay
4. cache extraction
5. save
6. next navigation

That is reliable, but most of the latency is browser navigation lifecycle, not image transfer.

## Structure of the supplied 333,313-URL list

The supplied list contains 333,313 URLs but only 165,903 distinct parent directories.

- 76,056 parent directories contain one image.
- 89,847 parent directories contain multiple images.
- 257,257 URLs (77.18%) are in a directory that has at least one sibling image.
- Mean images per parent directory: 2.009.
- Median: 2.
- Maximum observed group: 16 images.

The list is already ordered so sibling paths are generally contiguous. A directory is not a single downloadable bundle—the individual JPEG files still require individual HTTP responses—but this ordering is useful for connection reuse and browser prefetch.

## v0.5 pipeline

v0.5 keeps one same-origin Chromium/WebView document alive instead of navigating for every image.

### Anchor

The first pending image is loaded with the proven v0.4 top-level WebView path. A successful image becomes the same-origin browser anchor.

### Prefetch window

While an item is being processed, the next four pending URLs are inserted as ordinary `Image()` subresources in the same WebView. Chromium can request those resources concurrently and keep them in its normal cache/session.

### Fast item path

For each subsequent queue item:

1. Try a same-origin `fetch(..., cache='only-if-cached')`.
2. If already prefetched, transfer bytes immediately.
3. If not ready, load that URL as an `Image()` subresource and wait up to 8 seconds.
4. Read exact image bytes from Chromium cache.
5. If the fast path fails, fall back automatically to full top-level navigation for that item.

No native `HttpURLConnection` is used for protected images.

## Reliability retained from v0.4

- Foreground service
- Cellular process binding
- Overlay-attached 2x2 WebView for background execution
- WakeLock
- 5-second watchdog / stall recovery
- Strict item ID + token matching
- SQLite persistent queue and crash recovery
- `.part` -> validated final file
- 5,000-file output shards
- Existing v0.4 queue is preserved by the same application ID/database schema

## Logging optimization

Diagnostic logging is now sent to a dedicated background I/O executor. WebView callbacks no longer synchronously open and write the log file on the critical download path. Foreground-notification aggregate DB queries are also throttled to at most once every 2 seconds instead of once per image.

## What to look for in the log

Fast operation should show modes such as:

- `prefetch-cache-hit`
- `subresource-preload-cache`

Fallback cases will show:

- `FAST fallback ...`
- `BROWSER load ... reason=fast-fallback:...`

The first item after a fresh service start will normally be slower because it establishes the anchor.

## Prefetch concurrency

Default prefetch window is 4. This is intentionally conservative for an LTE connection and the remote service. Raising it further is possible, but should be based on observed error/rate-limit behavior instead of queue size alone.
