# Whisky LTE Downloader v0.8

Android Java proof-of-concept for a persistent, resumable Whiskybase image queue over cellular WebView.

## v0.8 changes

### 1) Version-stable shared output
New downloads are written through MediaStore into the user-visible shared Downloads tree:

`/storage/emulated/0/Download/WhiskyCrawler/<bucket>/<original-name>`

The bucket is derived from the numeric Whiskybase image id (`imageId / 5000`), not from the SQLite row id. Example:

`144629-big.jpg -> Download/WhiskyCrawler/0028/144629-big.jpg`

This makes the target deterministic across app updates and queue re-imports, while keeping each directory to a manageable number of files.

On first v0.8 service start, existing DONE files from the old app-private `Pictures/WhiskyCrawler` tree are migrated into the shared Downloads tree and the SQLite filename is updated. The old private copy is deleted only after the shared copy is finalized.

If the queue is intentionally cleared/re-created (or a fresh DB sees an existing shared corpus), `dedupe_scan_required` enables exact MediaStore target lookup so existing images are marked DONE without another network download.

### 2) ETA and throughput
The service maintains a rolling completion-rate window (up to 180 samples / ~3 minutes) and publishes:

- images/second
- images/hour
- ETA
- estimated completion time
- remaining terminal work

The main screen and foreground notification show the smoothed estimate. A previous rate is retained across service restarts so ETA does not drop to unknown after every manual verification.

### 3) Adaptive prefetch
Prefetch is now adaptive from 1 to 8 URLs ahead.

- sustained fast cache/preload completions gradually raise the window
- repeated fast-path fallbacks reduce it
- after user-completed verification the next run starts at 1 and remains cautious for ~45 seconds before ramping
- explicit Cloudflare verification pages are detected as such and the service pauses early instead of polling the page for the full 60 seconds

The app does **not** automate or bypass a verification challenge. `AuthActivity` remains visible/user-operated.

### 4) Prefetch readiness tracking
`window.__wcdPrefetch` now stores state (`loading`, `loaded`, `error`) for every ahead-of-queue image. The current item waits briefly for an in-flight preload before falling back to a full top-level navigation. This is intended to reduce the pattern seen in v0.5 where a cache check occurred just before the image preload completed.

### 5) Validated auth + auto resume
The auth completion button is disabled until the exact target URL is an actual loaded image document. Once the user confirms that verified image, the Activity saves the browser state, closes its process-level cellular binding, and restarts the foreground service after a short handoff delay.

## Existing core behavior retained

- SQLite queue with per-URL persistence/retries
- foreground `dataSync` service
- process-level cellular network binding
- overlay-attached 2x2 WebView for background execution
- partial wakelock
- strict URL/job token matching
- WebView/Chromium same-context byte extraction
- normal visible user verification when required
- watchdog/re-kick behavior
- asynchronous diagnostic log writing

## Important operational note

The WebView fast path can receive ordinary 403/cache misses while a browser subresource load still succeeds. Those are treated as fast-path observations. A real top-level verification page is distinguished by HTML/title/text signals and causes a user-verification pause.


## v0.8 automatic challenge recovery

When a real Cloudflare verification page is detected, v0.8 does not immediately force the user to press the auth-browser button. The foreground service keeps the queue safe, returns the current item to PENDING, reduces prefetch to 1, and performs conservative automatic retries after 90 s, 180 s, and 300 s. If the target image becomes normally reachable, the queue continues automatically.

If verification still persists after those retries, manual visible verification is still required. While MainActivity is in the foreground it opens AuthActivity automatically. AuthActivity never clicks or solves a challenge; it waits for the exact target image URL to become a verified image document. Once that happens, it saves the browser session and resumes the service automatically after a short stability delay, with no extra confirmation tap.


## v0.8 stall/MIME fixes

- Treats `HTTP 200 application/octet-stream` from image URLs as candidate image bytes and validates the final payload by magic bytes before commit. Cloudflare HTML cannot pass this validation.
- Bounds navigation watchdog re-kicks. After two consecutive 15-second navigation stalls, the downloader stops the infinite loop and automatically opens the visible auth browser for the exact stalled URL.
- AuthActivity now prefers the exact stalled/challenged target passed by the service instead of an unrelated first-pending URL.
- Start/Resume no longer resets an active byte transfer; it preserves in-flight work and only invokes recovery when the current item is already stalled.
- Interactive Cloudflare verification is still user-completed; the app only opens the visible browser, verifies that the exact target image eventually loaded, then resumes automatically.
