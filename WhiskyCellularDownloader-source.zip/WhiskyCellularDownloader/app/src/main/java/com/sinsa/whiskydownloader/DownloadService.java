package com.sinsa.whiskydownloader;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.net.Network;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.StatFs;
import android.webkit.CookieManager;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DownloadService extends Service {
    public static final String ACTION_START = "com.sinsa.whiskydownloader.START";
    public static final String ACTION_PAUSE = "com.sinsa.whiskydownloader.PAUSE";
    private static final String CHANNEL = "download";
    private static final int NOTIFICATION_ID = 7;
    // v0.1 used 5 GiB and silently collapsed the reason to generic PAUSED.
    // v0.2 keeps a smaller safety floor and exposes the exact stop reason.
    private static final long MIN_FREE_BYTES = 512L * 1024 * 1024;

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private volatile boolean running;
    private QueueDb db;
    private PowerManager.WakeLock wakeLock;

    @Override public void onCreate() {
        super.onCreate();
        db = new QueueDb(this);
        db.recoverInterrupted();
        createChannel();
        AppLog.d(this, "SERVICE created");
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        AppLog.d(this, "SERVICE command action=" + action + " running=" + running);
        if (ACTION_PAUSE.equals(action)) {
            pauseWithReason("PAUSED BY USER", "-");
            return START_NOT_STICKY;
        }

        Notification n = notification("Starting on cellular…");
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(NOTIFICATION_ID, n);
        }

        if (!running) {
            running = true;
            prefs().edit().putBoolean("paused", false).remove("pause_reason").apply();
            setState("START REQUESTED", "-");
            worker.execute(this::runLoop);
        } else {
            prefs().edit().putBoolean("paused", false).remove("pause_reason").apply();
            AppLog.d(this, "SERVICE already running; cleared pause flag");
        }
        return START_NOT_STICKY;
    }

    private void runLoop() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WhiskyDownloader:worker");
        wakeLock.acquire(6 * 60 * 60 * 1000L);
        try {
            setState("WAITING FOR CELLULAR", "-");
            AppLog.d(this, "NETWORK waiting for cellular");
            Network network = CellularNetwork.await(this, 30);
            if (network == null) {
                setState("NO CELLULAR NETWORK", "-");
                AppLog.d(this, "NETWORK no cellular network after 30s");
                return;
            }
            AppLog.d(this, "NETWORK cellular acquired " + network);
            setState("RUNNING", "-");
            int idleLoops = 0;
            while (!isPaused()) {
                File dir = outputDir();
                if (!dir.exists() && !dir.mkdirs()) {
                    setState("OUTPUT DIRECTORY ERROR", dir.getAbsolutePath());
                    AppLog.d(this, "STORAGE cannot create " + dir);
                    break;
                }
                long free = new StatFs(dir.getAbsolutePath()).getAvailableBytes();
                prefs().edit().putLong("free_bytes", free).apply();
                if (free < MIN_FREE_BYTES) {
                    pauseWithReason("PAUSED: LOW STORAGE", humanBytes(free) + " free");
                    AppLog.d(this, "STORAGE pause free=" + free + " dir=" + dir);
                    break;
                }

                QueueDb.Item item = db.claimNext();
                if (item == null) {
                    QueueDb.Stats stats = db.stats();
                    if (stats.counts[QueueDb.RETRY] > 0 && idleLoops < 120) {
                        idleLoops++;
                        sleep(5000);
                        continue;
                    }
                    setState("IDLE / QUEUE COMPLETE", "-");
                    AppLog.d(this, "QUEUE no claimable item; total=" + stats.total());
                    break;
                }
                idleLoops = 0;
                setState("RUNNING", "#" + item.id + " " + item.url);
                AppLog.d(this, "GET start id=" + item.id + " retry=" + item.retryCount + " url=" + item.url);
                processOne(network, item, dir);
                updateNotification();
            }
            if (isPaused()) {
                String reason = prefs().getString("pause_reason", "PAUSED");
                String current = prefs().getString("pause_current", "-");
                setState(reason, current);
                AppLog.d(this, "SERVICE loop stopped because paused reason=" + reason + " current=" + current);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            setState("INTERRUPTED", "-");
            AppLog.d(this, "SERVICE interrupted");
        } catch (Throwable t) {
            setState("SERVICE ERROR", t.getClass().getSimpleName() + ": " + t.getMessage());
            AppLog.d(this, "SERVICE fatal " + t);
        } finally {
            running = false;
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
            stopForeground(STOP_FOREGROUND_DETACH);
            stopSelf();
            AppLog.d(this, "SERVICE worker ended");
        }
    }

    private void processOne(Network network, QueueDb.Item item, File dir) {
        HttpURLConnection c = null;
        try {
            URL url = new URL(item.url);
            c = (HttpURLConnection) network.openConnection(url);
            c.setInstanceFollowRedirects(true);
            c.setConnectTimeout(20_000);
            c.setReadTimeout(45_000);
            c.setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8");
            c.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
            String ua = prefs().getString("user_agent",
                    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/131.0 Mobile Safari/537.36");
            c.setRequestProperty("User-Agent", ua);
            String cookie = CookieManager.getInstance().getCookie(item.url);
            boolean cookiePresent = cookie != null && !cookie.isEmpty();
            if (cookiePresent) c.setRequestProperty("Cookie", cookie);

            int code = c.getResponseCode();
            String mime = c.getContentType();
            if (mime != null) {
                int semi = mime.indexOf(';');
                if (semi >= 0) mime = mime.substring(0, semi).trim().toLowerCase(Locale.US);
            }
            AppLog.d(this, "GET response id=" + item.id + " http=" + code + " mime=" + mime + " cookie_present=" + cookiePresent + " final_url=" + c.getURL());

            if (code == 200 && mime != null && mime.startsWith("image/")) {
                String base = safeBaseName(url.getPath());
                String finalName = String.format(Locale.US, "%09d_%s", item.id, base);
                File part = new File(dir, finalName + ".part");
                File fin = new File(dir, finalName);
                long size = copy(c, part);
                if (size <= 0 || !looksLikeImage(part, mime)) {
                    //noinspection ResultOfMethodCallIgnored
                    part.delete();
                    scheduleRetry(item, code, mime, "Image validation failed");
                    AppLog.d(this, "GET validation failed id=" + item.id + " size=" + size);
                    return;
                }
                if (fin.exists() && !fin.delete()) throw new IOException("Cannot replace existing file");
                if (!part.renameTo(fin)) throw new IOException("Atomic rename failed");
                db.markDone(item.id, finalName, size, code, mime);
                AppLog.d(this, "GET done id=" + item.id + " bytes=" + size + " file=" + finalName);
                return;
            }

            if (code == 403 || code == 503 || (mime != null && mime.contains("text/html") && code < 500)) {
                String preview = readSmall(c, 4096);
                String err = "Authentication/browser verification may be required. HTTP " + code + " " + preview;
                db.returnToPending(item.id, err);
                pauseWithReason("AUTH REQUIRED — OPEN BROWSER", item.url);
                AppLog.d(this, "AUTH_REQUIRED id=" + item.id + " http=" + code + " mime=" + mime + " cookie_present=" + cookiePresent + " preview=" + trim(preview, 500));
                return;
            }

            if (code == 404 || code == 410) {
                db.markSkipped(item.id, code, mime, "Not found");
                AppLog.d(this, "GET skipped not-found id=" + item.id + " http=" + code);
                return;
            }

            if (code == 429 || code >= 500) {
                scheduleRetry(item, code, mime, "HTTP " + code);
                return;
            }

            if (code >= 200 && code < 400 && (mime == null || !mime.startsWith("image/"))) {
                db.markSkipped(item.id, code, mime, "Non-image response");
                AppLog.d(this, "GET skipped non-image id=" + item.id + " http=" + code + " mime=" + mime);
                return;
            }
            scheduleRetry(item, code, mime, "Unexpected HTTP " + code);
        } catch (Exception e) {
            AppLog.d(this, "GET exception id=" + item.id + " " + e);
            scheduleRetry(item, 0, null, e.getClass().getSimpleName() + ": " + e.getMessage());
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private void scheduleRetry(QueueDb.Item item, int code, String mime, String error) {
        int r = item.retryCount + 1;
        if (r > 5) {
            db.markFailed(item.id, code, mime, error);
            AppLog.d(this, "RETRY exhausted id=" + item.id + " error=" + error);
            return;
        }
        long[] backoff = {5_000L, 30_000L, 120_000L, 600_000L, 1_800_000L};
        long delay = backoff[Math.min(r - 1, backoff.length - 1)];
        db.markRetry(item.id, r, delay, code, mime, error);
        AppLog.d(this, "RETRY scheduled id=" + item.id + " attempt=" + r + " delay_ms=" + delay + " http=" + code + " error=" + error);
    }

    private long copy(HttpURLConnection c, File dst) throws IOException {
        long total = 0;
        byte[] buf = new byte[128 * 1024];
        try (BufferedInputStream in = new BufferedInputStream(c.getInputStream(), 128 * 1024);
             BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(dst), 128 * 1024)) {
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
                total += n;
            }
            out.flush();
        }
        return total;
    }

    private static boolean looksLikeImage(File f, String mime) {
        byte[] h = new byte[16];
        try (FileInputStream in = new FileInputStream(f)) {
            int n = in.read(h);
            if (n < 3) return false;
            if (mime.contains("jpeg") || mime.contains("jpg")) return (h[0]&255)==0xFF && (h[1]&255)==0xD8 && (h[2]&255)==0xFF;
            if (mime.contains("png")) return n>=8 && (h[0]&255)==0x89 && h[1]=='P' && h[2]=='N' && h[3]=='G';
            if (mime.contains("gif")) return h[0]=='G' && h[1]=='I' && h[2]=='F';
            if (mime.contains("webp")) return n>=12 && h[0]=='R' && h[1]=='I' && h[2]=='F' && h[3]=='F' && h[8]=='W' && h[9]=='E' && h[10]=='B' && h[11]=='P';
            return f.length() > 512;
        } catch (Exception e) { return false; }
    }

    private String readSmall(HttpURLConnection c, int max) {
        try {
            java.io.InputStream raw = c.getErrorStream();
            if (raw == null) raw = c.getInputStream();
            byte[] b = new byte[max];
            int n = raw.read(b);
            raw.close();
            return n <= 0 ? "" : new String(b, 0, n, StandardCharsets.UTF_8).replaceAll("\\s+", " ");
        } catch (Exception ignored) { return ""; }
    }

    private File outputDir() {
        File base = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        if (base == null) base = getFilesDir();
        return new File(base, "WhiskyCrawler");
    }

    private static String safeBaseName(String path) {
        String name = path == null ? "image.bin" : path.substring(path.lastIndexOf('/') + 1);
        if (name.isEmpty()) name = "image.bin";
        name = name.replaceAll("[^A-Za-z0-9._-]", "_");
        if (name.length() > 120) name = name.substring(name.length() - 120);
        return name;
    }

    private boolean isPaused() { return prefs().getBoolean("paused", false); }

    private SharedPreferences prefs() { return getSharedPreferences("state", MODE_PRIVATE); }

    private void pauseWithReason(String reason, String current) {
        prefs().edit().putBoolean("paused", true).putString("pause_reason", reason)
                .putString("pause_current", current == null ? "-" : current).apply();
        setState(reason, current);
    }

    private void setState(String state, String current) {
        prefs().edit().putString("service_status", state)
                .putString("current", current == null ? "-" : current)
                .putLong("last_state_at", System.currentTimeMillis()).apply();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Image downloads", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Persistent cellular image download queue");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent pause = new Intent(this, DownloadService.class).setAction(ACTION_PAUSE);
        PendingIntent pPause = PendingIntent.getService(this, 1, pause, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("Whisky LTE Downloader")
                .setContentText(text)
                .setContentIntent(pi)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "Pause", pPause).build())
                .build();
    }

    private void updateNotification() {
        QueueDb.Stats s = db.stats();
        long done = s.counts[QueueDb.DONE];
        long total = s.total();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(
                NOTIFICATION_ID, notification(String.format(Locale.US, "%,d / %,d · %s", done, total, humanBytes(s.bytes))));
    }

    private static String humanBytes(long b) {
        double v=b; String[] u={"B","KB","MB","GB","TB"}; int i=0;
        while(v>=1024 && i<u.length-1){v/=1024;i++;}
        return String.format(Locale.US,"%.1f %s",v,u[i]);
    }

    private static String trim(String s, int n) { return s == null || s.length() <= n ? s : s.substring(0, n); }
    private static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }

    @Override public void onTimeout(int startId, int fgsType) {
        pauseWithReason("PAUSED BY ANDROID FGS TIMEOUT", "-");
        AppLog.d(this, "SERVICE Android FGS timeout");
        stopSelf();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onDestroy() {
        running = false;
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        if (db != null) db.close();
        worker.shutdownNow();
        AppLog.d(this, "SERVICE destroyed");
        super.onDestroy();
    }
}
