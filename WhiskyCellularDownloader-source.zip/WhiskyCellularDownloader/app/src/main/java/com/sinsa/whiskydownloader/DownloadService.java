package com.sinsa.whiskydownloader;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.net.Network;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.StatFs;
import android.util.Base64;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * v0.3 browser-direct downloader.
 *
 * Important design choice: every protected image is first loaded by Android WebView itself.
 * The app does NOT copy WebView cookies into HttpURLConnection.  After the image document is
 * visibly/semantically loaded, JavaScript running inside that same WebView reads the image bytes
 * from Chromium's cache/session and sends them to Java in small chunks.  If the cache fetch is not
 * available, a canvas copy is used as a last-resort fallback.
 *
 * There is no challenge automation here.  If the background WebView cannot reach an image document
 * within CHALLENGE_WAIT_MS, the queue is paused and the user is asked to open AuthActivity.
 */
public class DownloadService extends Service {
    public static final String ACTION_START = "com.sinsa.whiskydownloader.START";
    public static final String ACTION_PAUSE = "com.sinsa.whiskydownloader.PAUSE";

    private static final String CHANNEL = "download";
    private static final int NOTIFICATION_ID = 7;
    private static final long MIN_FREE_BYTES = 512L * 1024 * 1024;
    private static final long CHALLENGE_WAIT_MS = 60_000L;
    private static final long PAGE_HARD_TIMEOUT_MS = 100_000L;
    private static final long INSPECT_INTERVAL_MS = 1_500L;
    private static final long BETWEEN_ITEMS_MS = 250L;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService networkWorker = Executors.newSingleThreadExecutor();
    private final Object transferLock = new Object();

    private QueueDb db;
    private WebView webView;
    private PowerManager.WakeLock wakeLock;
    private volatile boolean active;
    private volatile boolean pauseAfterCurrent;

    private QueueDb.Item currentItem;
    private String currentToken;
    private long currentStartedAt;
    private int inspectCount;
    private boolean extractionStarted;

    // Chunk transfer state. Access only inside synchronized(transferLock).
    private BufferedOutputStream currentOut;
    private File currentPart;
    private File currentFinal;
    private String currentFinalName;
    private String currentMime;
    private String currentExtractMode;
    private int expectedChunks;
    private int receivedChunks;
    private long expectedBytes;
    private long receivedBytes;

    @Override public void onCreate() {
        super.onCreate();
        db = new QueueDb(this);
        db.recoverInterrupted();
        createChannel();
        AppLog.d(this, "SERVICE v0.3 created engine=webview-direct");
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        AppLog.d(this, "SERVICE command action=" + action + " active=" + active);

        if (ACTION_PAUSE.equals(action)) {
            pauseAfterCurrent = true;
            prefs().edit().putBoolean("pause_requested", true).apply();
            AppLog.d(this, "PAUSE requested; current item will be allowed to finish");
            if (!active || currentItem == null) {
                setState("PAUSED BY USER", "-");
                stopForeground(STOP_FOREGROUND_DETACH);
                stopSelf();
            } else {
                setState("PAUSE REQUESTED — FINISHING CURRENT", "#" + currentItem.id + " " + currentItem.url);
                updateNotification("Pause requested — finishing current image");
            }
            return START_NOT_STICKY;
        }

        startAsForeground("Starting browser-direct engine on cellular…");
        if (active) {
            pauseAfterCurrent = false;
            prefs().edit().putBoolean("pause_requested", false).apply();
            AppLog.d(this, "SERVICE already active; resume flag cleared");
            return START_NOT_STICKY;
        }

        active = true;
        pauseAfterCurrent = false;
        prefs().edit()
                .putBoolean("pause_requested", false)
                .remove("pause_reason")
                .putString("browser_engine", "WEBVIEW DIRECT")
                .apply();
        acquireWakeLock();
        setState("WAITING FOR CELLULAR", "-");

        networkWorker.execute(() -> {
            try {
                AppLog.d(this, "NETWORK binding whole app process to cellular");
                Network n = CellularNetwork.bindProcess(this, 30);
                if (n == null) {
                    main.post(() -> stopWithReason("NO CELLULAR NETWORK", "Enable mobile data and try again", false));
                    return;
                }
                AppLog.d(this, "NETWORK process bound to cellular " + n);
                main.post(() -> {
                    prefs().edit().putString("browser_network", "CELLULAR").apply();
                    ensureWebView();
                    startNext();
                });
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                main.post(() -> stopWithReason("INTERRUPTED", "Cellular binding interrupted", false));
            } catch (Throwable t) {
                AppLog.d(this, "NETWORK bind fatal " + t);
                main.post(() -> stopWithReason("NETWORK ERROR", t.getClass().getSimpleName() + ": " + t.getMessage(), false));
            }
        });
        return START_NOT_STICKY;
    }

    private void ensureWebView() {
        if (webView != null) return;
        try {
            webView = new WebView(this);
            WebSettings s = webView.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setDatabaseEnabled(true);
            s.setLoadsImagesAutomatically(true);
            s.setBlockNetworkImage(false);
            s.setCacheMode(WebSettings.LOAD_DEFAULT);
            if (Build.VERSION.SDK_INT >= 23) s.setOffscreenPreRaster(true);

            CookieManager cm = CookieManager.getInstance();
            cm.setAcceptCookie(true);
            if (Build.VERSION.SDK_INT >= 21) cm.setAcceptThirdPartyCookies(webView, true);

            webView.addJavascriptInterface(new BrowserBridge(), "AndroidBridge");
            webView.setWebViewClient(new WebViewClient() {
                @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                    if (currentItem != null) {
                        AppLog.d(DownloadService.this, "BROWSER page started id=" + currentItem.id + " url=" + url);
                        prefs().edit().putString("browser_stage", "PAGE STARTED").apply();
                    }
                }

                @Override public void onPageFinished(WebView view, String url) {
                    if (currentItem == null) return;
                    AppLog.d(DownloadService.this, "BROWSER page finished id=" + currentItem.id + " url=" + url + " title=" + view.getTitle());
                    prefs().edit().putString("browser_stage", "PAGE FINISHED / INSPECTING").apply();
                    scheduleInspect(650L);
                }

                @Override public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse response) {
                    if (currentItem == null || request == null || !request.isForMainFrame()) return;
                    int code = response == null ? 0 : response.getStatusCode();
                    String mime = response == null ? null : response.getMimeType();
                    prefs().edit().putInt("browser_last_http", code).putString("browser_last_mime", nullToDash(mime)).apply();
                    AppLog.d(DownloadService.this, "BROWSER main HTTP id=" + currentItem.id + " http=" + code + " mime=" + mime + " url=" + request.getUrl());
                    // Do not pause here: Cloudflare may intentionally serve an HTML challenge first and
                    // then navigate to the image. The inspection watchdog decides after a grace period.
                    scheduleInspect(1_500L);
                }

                @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                    if (currentItem == null || request == null || !request.isForMainFrame()) return;
                    String msg = error == null ? "unknown" : String.valueOf(error.getDescription());
                    AppLog.d(DownloadService.this, "BROWSER main error id=" + currentItem.id + " code=" + (error == null ? 0 : error.getErrorCode()) + " msg=" + msg);
                    prefs().edit().putString("browser_stage", "LOAD ERROR / WAITING").apply();
                    scheduleInspect(2_000L);
                }
            });
            AppLog.d(this, "BROWSER hidden WebView initialized ua=" + s.getUserAgentString());
        } catch (Throwable t) {
            AppLog.d(this, "BROWSER initialization failed " + t);
            stopWithReason("WEBVIEW INIT ERROR", t.getClass().getSimpleName() + ": " + t.getMessage(), false);
        }
    }

    private void startNext() {
        if (!active) return;
        if (pauseAfterCurrent || prefs().getBoolean("pause_requested", false)) {
            stopWithReason("PAUSED BY USER", "-", false);
            return;
        }
        if (webView == null) {
            ensureWebView();
            if (webView == null) return;
        }

        File root = outputRoot();
        if (!root.exists() && !root.mkdirs()) {
            stopWithReason("OUTPUT DIRECTORY ERROR", root.getAbsolutePath(), false);
            return;
        }
        long free = new StatFs(root.getAbsolutePath()).getAvailableBytes();
        prefs().edit().putLong("free_bytes", free).apply();
        if (free < MIN_FREE_BYTES) {
            stopWithReason("PAUSED: LOW STORAGE", humanBytes(free) + " free", false);
            return;
        }

        QueueDb.Item item = db.claimNext();
        if (item == null) {
            QueueDb.Stats stats = db.stats();
            if (stats.counts[QueueDb.RETRY] > 0) {
                setState("WAITING FOR RETRY", "-");
                main.postDelayed(this::startNext, 5_000L);
                return;
            }
            setState("IDLE / QUEUE COMPLETE", "-");
            AppLog.d(this, "QUEUE complete total=" + stats.total());
            finishService(false);
            return;
        }

        currentItem = item;
        currentToken = UUID.randomUUID().toString();
        currentStartedAt = System.currentTimeMillis();
        inspectCount = 0;
        extractionStarted = false;
        resetTransferState(true);

        setState("BROWSER LOADING", "#" + item.id + " " + item.url);
        prefs().edit()
                .putString("browser_stage", "NAVIGATING")
                .putInt("browser_last_http", 0)
                .putString("browser_last_mime", "-")
                .putString("browser_extract_mode", "-")
                .apply();
        AppLog.d(this, "BROWSER load id=" + item.id + " retry=" + item.retryCount + " url=" + item.url);

        try {
            webView.stopLoading();
            webView.loadUrl(item.url);
            final long id = item.id;
            final String token = currentToken;
            main.postDelayed(() -> {
                if (!isCurrent(id, token) || extractionStarted) return;
                long elapsed = System.currentTimeMillis() - currentStartedAt;
                AppLog.d(this, "BROWSER hard-timeout id=" + id + " elapsed_ms=" + elapsed);
                authRequired("Browser did not become an image document within " + (elapsed / 1000) + "s");
            }, PAGE_HARD_TIMEOUT_MS);
            scheduleInspect(1_000L);
        } catch (Throwable t) {
            AppLog.d(this, "BROWSER load exception id=" + item.id + " " + t);
            retryCurrent("WebView load exception: " + t.getClass().getSimpleName() + ": " + t.getMessage(), 0, null);
        }
    }

    private void scheduleInspect(long delayMs) {
        if (!active || currentItem == null || extractionStarted) return;
        final long id = currentItem.id;
        final String token = currentToken;
        main.postDelayed(() -> {
            if (!isCurrent(id, token) || extractionStarted) return;
            inspectCurrent(id, token);
        }, delayMs);
    }

    private void inspectCurrent(long id, String token) {
        if (!isCurrent(id, token) || webView == null || extractionStarted) return;
        inspectCount++;
        String js = "(function(){try{" +
                "var ct=(document.contentType||'').toLowerCase();" +
                "var imgs=document.images||[];var img=imgs.length?imgs[0]:null;" +
                "var txt=((document.body&&document.body.innerText)||'').trim();" +
                "var href=location.href||'';" +
                "var ext=/\\.(jpe?g|png|webp|gif|avif)(?:$|[?#])/i.test(href);" +
                "var one=!!(imgs.length===1&&img&&img.complete&&img.naturalWidth>0);" +
                "var imageLike=(ct.indexOf('image/')===0)||(ext&&one&&txt.length<64);" +
                "AndroidBridge.onInspect('" + token + "'," + id + ",imageLike,ct,(document.title||''),imgs.length,(img&&img.currentSrc)||'',txt.substring(0,220));" +
                "}catch(e){AndroidBridge.onInspectError('" + token + "'," + id + ",String(e));}})();";
        try {
            webView.evaluateJavascript(js, null);
        } catch (Throwable t) {
            AppLog.d(this, "BROWSER inspect evaluate failed id=" + id + " " + t);
            retryCurrent("WebView inspect failed: " + t.getMessage(), 0, null);
        }
    }

    private void beginExtraction(long id, String token) {
        if (!isCurrent(id, token) || extractionStarted || webView == null) return;
        extractionStarted = true;
        setState("EXTRACTING IN WEBVIEW", "#" + id + " " + currentItem.url);
        prefs().edit().putString("browser_stage", "EXTRACTING").apply();
        AppLog.d(this, "BROWSER extract start id=" + id + " using cache/session; canvas fallback enabled");

        // All protected network access below is executed by this same Chromium/WebView session.
        // The first fetch asks Chromium for an already cached same-origin response.  If unavailable,
        // force-cache is tried.  A canvas copy of the already displayed image is the final fallback.
        String js = "(async function(){" +
                "const T='" + token + "',ID=" + id + ";" +
                "function sendBytes(u8,mime,mode){" +
                " const C=49152,total=Math.ceil(u8.length/C);" +
                " AndroidBridge.onBegin(T,ID,mime||'image/jpeg',u8.length,total,mode);" +
                " for(let i=0;i<total;i++){let a=i*C,b=Math.min(u8.length,a+C),bin='';" +
                "   for(let j=a;j<b;j+=8192){let e=Math.min(b,j+8192);bin+=String.fromCharCode.apply(null,u8.slice(j,e));}" +
                "   AndroidBridge.onChunk(T,ID,i,btoa(bin));}" +
                " AndroidBridge.onComplete(T,ID);}" +
                "async function tryFetch(cacheMode){try{" +
                " const r=await fetch(location.href,{credentials:'include',cache:cacheMode,mode:'same-origin'});" +
                " const ct=(r.headers.get('content-type')||'').split(';')[0].toLowerCase();" +
                " if(r.ok&&ct.indexOf('image/')===0){sendBytes(new Uint8Array(await r.arrayBuffer()),ct,'fetch-'+cacheMode);return true;}" +
                " AndroidBridge.onFetchObservation(T,ID,r.status,ct,'fetch-'+cacheMode);return false;" +
                "}catch(e){AndroidBridge.onFetchObservation(T,ID,0,'',cacheMode+': '+String(e));return false;}}" +
                "try{" +
                " if(await tryFetch('only-if-cached'))return;" +
                " if(await tryFetch('force-cache'))return;" +
                " const imgs=document.images||[];const img=imgs.length?imgs[0]:null;" +
                " if(!img||!img.complete||!img.naturalWidth){AndroidBridge.onExtractFailure(T,ID,'No loaded image element for canvas fallback');return;}" +
                " const cv=document.createElement('canvas');cv.width=img.naturalWidth;cv.height=img.naturalHeight;" +
                " const cx=cv.getContext('2d');cx.drawImage(img,0,0);" +
                " const mime=((document.contentType||'image/jpeg').toLowerCase().indexOf('png')>=0)?'image/png':'image/jpeg';" +
                " const blob=await new Promise((resolve,reject)=>cv.toBlob(b=>b?resolve(b):reject(new Error('canvas toBlob failed')),mime,1.0));" +
                " sendBytes(new Uint8Array(await blob.arrayBuffer()),mime,'canvas-fallback');" +
                "}catch(e){AndroidBridge.onExtractFailure(T,ID,String(e));}" +
                "})();";
        try {
            webView.evaluateJavascript(js, null);
        } catch (Throwable t) {
            extractionStarted = false;
            retryCurrent("Extraction injection failed: " + t.getMessage(), 0, null);
        }
    }

    private final class BrowserBridge {
        @JavascriptInterface public void onInspect(String token, long id, boolean imageLike, String contentType,
                                                   String title, int imageCount, String currentSrc, String textPreview) {
            if (!isCurrent(id, token)) return;
            long elapsed = System.currentTimeMillis() - currentStartedAt;
            if (inspectCount == 1 || inspectCount % 5 == 0 || imageLike) {
                AppLog.d(DownloadService.this, "BROWSER inspect id=" + id + " image=" + imageLike + " ct=" + contentType +
                        " images=" + imageCount + " elapsed_ms=" + elapsed + " title=" + trim(title, 120) +
                        " text=" + trim(textPreview, 180));
            }
            prefs().edit().putString("browser_last_mime", nullToDash(contentType)).apply();
            if (imageLike) {
                main.post(() -> beginExtraction(id, token));
            } else if (elapsed >= CHALLENGE_WAIT_MS) {
                main.post(() -> authRequired("Verification page still present after " + (elapsed / 1000) + "s. title=" + trim(title, 100)));
            } else {
                main.post(() -> scheduleInspect(INSPECT_INTERVAL_MS));
            }
        }

        @JavascriptInterface public void onInspectError(String token, long id, String error) {
            if (!isCurrent(id, token)) return;
            AppLog.d(DownloadService.this, "BROWSER inspect JS error id=" + id + " " + error);
            main.post(() -> scheduleInspect(INSPECT_INTERVAL_MS));
        }

        @JavascriptInterface public void onFetchObservation(String token, long id, int status, String mime, String detail) {
            if (!isCurrent(id, token)) return;
            AppLog.d(DownloadService.this, "BROWSER extract observation id=" + id + " http=" + status + " mime=" + mime + " detail=" + detail);
            prefs().edit().putInt("browser_last_http", status).putString("browser_last_mime", nullToDash(mime)).apply();
        }

        @JavascriptInterface public void onBegin(String token, long id, String mime, long totalBytes, int chunks, String mode) {
            if (!isCurrent(id, token)) return;
            synchronized (transferLock) {
                try {
                    resetTransferStateLocked(true);
                    File dir = outputDirFor(id);
                    if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cannot create output shard " + dir);
                    String base = safeBaseName(new URL(currentItem.url).getPath());
                    base = ensureExtension(base, mime);
                    currentFinalName = String.format(Locale.US, "%09d_%s", id, base);
                    currentPart = new File(dir, currentFinalName + ".part");
                    currentFinal = new File(dir, currentFinalName);
                    //noinspection ResultOfMethodCallIgnored
                    currentPart.delete();
                    currentOut = new BufferedOutputStream(new FileOutputStream(currentPart), 128 * 1024);
                    currentMime = normalizeMime(mime);
                    currentExtractMode = mode == null ? "unknown" : mode;
                    expectedChunks = chunks;
                    expectedBytes = totalBytes;
                    receivedChunks = 0;
                    receivedBytes = 0;
                    prefs().edit().putString("browser_extract_mode", currentExtractMode).putString("browser_stage", "TRANSFERRING BYTES").apply();
                    AppLog.d(DownloadService.this, "TRANSFER begin id=" + id + " bytes=" + totalBytes + " chunks=" + chunks + " mime=" + currentMime + " mode=" + currentExtractMode);
                } catch (Throwable t) {
                    AppLog.d(DownloadService.this, "TRANSFER begin failed id=" + id + " " + t);
                    main.post(() -> retryCurrent("Transfer begin failed: " + t.getMessage(), 0, mime));
                }
            }
        }

        @JavascriptInterface public void onChunk(String token, long id, int index, String base64) {
            if (!isCurrent(id, token)) return;
            synchronized (transferLock) {
                if (currentOut == null) return;
                try {
                    if (index != receivedChunks) throw new IOException("Chunk order mismatch expected=" + receivedChunks + " got=" + index);
                    byte[] b = Base64.decode(base64, Base64.DEFAULT);
                    currentOut.write(b);
                    receivedBytes += b.length;
                    receivedChunks++;
                    if (receivedChunks % 25 == 0) {
                        prefs().edit().putString("browser_stage", "TRANSFERRING " + receivedChunks + "/" + expectedChunks).apply();
                    }
                } catch (Throwable t) {
                    AppLog.d(DownloadService.this, "TRANSFER chunk failed id=" + id + " index=" + index + " " + t);
                    closeCurrentOutLocked();
                    main.post(() -> retryCurrent("Chunk transfer failed: " + t.getMessage(), 0, currentMime));
                }
            }
        }

        @JavascriptInterface public void onComplete(String token, long id) {
            if (!isCurrent(id, token)) return;
            synchronized (transferLock) {
                try {
                    if (currentOut == null || currentPart == null || currentFinal == null) throw new IOException("Transfer was not initialized");
                    currentOut.flush();
                    currentOut.close();
                    currentOut = null;
                    if (receivedChunks != expectedChunks) throw new IOException("Incomplete chunks " + receivedChunks + "/" + expectedChunks);
                    if (expectedBytes >= 0 && receivedBytes != expectedBytes) throw new IOException("Byte count mismatch " + receivedBytes + "/" + expectedBytes);
                    if (receivedBytes <= 0 || !looksLikeImage(currentPart, currentMime)) throw new IOException("Image validation failed");
                    if (currentFinal.exists() && !currentFinal.delete()) throw new IOException("Cannot replace existing final file");
                    if (!currentPart.renameTo(currentFinal)) throw new IOException("Atomic rename failed");

                    String dbName = currentFinal.getParentFile().getName() + "/" + currentFinalName;
                    db.markDone(id, dbName, receivedBytes, 200, currentMime);
                    AppLog.d(DownloadService.this, "TRANSFER done id=" + id + " bytes=" + receivedBytes + " file=" + dbName + " mode=" + currentExtractMode);
                    prefs().edit().putString("browser_stage", "DONE").apply();
                    clearCurrentAfterSuccess();
                    main.post(() -> {
                        updateNotification(null);
                        if (pauseAfterCurrent || prefs().getBoolean("pause_requested", false)) {
                            stopWithReason("PAUSED BY USER", "-", false);
                        } else {
                            main.postDelayed(DownloadService.this::startNext, BETWEEN_ITEMS_MS);
                        }
                    });
                } catch (Throwable t) {
                    AppLog.d(DownloadService.this, "TRANSFER complete failed id=" + id + " " + t);
                    closeCurrentOutLocked();
                    main.post(() -> retryCurrent("Transfer validation/finalize failed: " + t.getMessage(), 0, currentMime));
                }
            }
        }

        @JavascriptInterface public void onExtractFailure(String token, long id, String error) {
            if (!isCurrent(id, token)) return;
            AppLog.d(DownloadService.this, "BROWSER extraction failed id=" + id + " " + error);
            main.post(() -> retryCurrent("Browser extraction failed: " + error, prefs().getInt("browser_last_http", 0), prefs().getString("browser_last_mime", null)));
        }
    }

    private void authRequired(String detail) {
        if (currentItem == null) return;
        long id = currentItem.id;
        String url = currentItem.url;
        resetTransferState(true);
        db.returnToPending(id, "Browser verification required. " + detail);
        AppLog.d(this, "AUTH_REQUIRED id=" + id + " detail=" + detail + " url=" + url);
        stopWithReason("AUTH REQUIRED — OPEN BROWSER", url, false);
    }

    private void retryCurrent(String error, int code, String mime) {
        if (currentItem == null) return;
        QueueDb.Item item = currentItem;
        resetTransferState(true);
        int r = item.retryCount + 1;
        if (r > 5) {
            db.markFailed(item.id, code, mime, error);
            AppLog.d(this, "RETRY exhausted id=" + item.id + " error=" + error);
        } else {
            long[] backoff = {5_000L, 30_000L, 120_000L, 600_000L, 1_800_000L};
            long delay = backoff[Math.min(r - 1, backoff.length - 1)];
            db.markRetry(item.id, r, delay, code, mime, error);
            AppLog.d(this, "RETRY scheduled id=" + item.id + " attempt=" + r + " delay_ms=" + delay + " error=" + error);
        }
        currentItem = null;
        currentToken = null;
        extractionStarted = false;
        main.postDelayed(this::startNext, BETWEEN_ITEMS_MS);
    }

    private void clearCurrentAfterSuccess() {
        synchronized (transferLock) {
            closeCurrentOutLocked();
            currentPart = null;
            currentFinal = null;
            currentFinalName = null;
            currentMime = null;
            currentExtractMode = null;
            expectedChunks = 0;
            receivedChunks = 0;
            expectedBytes = 0;
            receivedBytes = 0;
        }
        currentItem = null;
        currentToken = null;
        extractionStarted = false;
    }

    private void resetTransferState(boolean deletePart) {
        synchronized (transferLock) { resetTransferStateLocked(deletePart); }
    }

    private void resetTransferStateLocked(boolean deletePart) {
        closeCurrentOutLocked();
        if (deletePart && currentPart != null) {
            //noinspection ResultOfMethodCallIgnored
            currentPart.delete();
        }
        currentPart = null;
        currentFinal = null;
        currentFinalName = null;
        currentMime = null;
        currentExtractMode = null;
        expectedChunks = 0;
        receivedChunks = 0;
        expectedBytes = 0;
        receivedBytes = 0;
    }

    private void closeCurrentOutLocked() {
        if (currentOut != null) {
            try { currentOut.close(); } catch (Exception ignored) {}
            currentOut = null;
        }
    }

    private boolean isCurrent(long id, String token) {
        QueueDb.Item item = currentItem;
        return active && item != null && item.id == id && token != null && token.equals(currentToken);
    }

    private File outputRoot() {
        File base = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        if (base == null) base = getFilesDir();
        return new File(base, "WhiskyCrawler");
    }

    private File outputDirFor(long id) {
        long bucket = (Math.max(1L, id) - 1L) / 5000L;
        return new File(outputRoot(), String.format(Locale.US, "%04d", bucket));
    }

    private static String safeBaseName(String path) {
        String name = path == null ? "image.bin" : path.substring(path.lastIndexOf('/') + 1);
        if (name.isEmpty()) name = "image.bin";
        name = name.replaceAll("[^A-Za-z0-9._-]", "_");
        if (name.length() > 120) name = name.substring(name.length() - 120);
        return name;
    }

    private static String ensureExtension(String base, String mime) {
        String low = base.toLowerCase(Locale.US);
        if (low.endsWith(".jpg") || low.endsWith(".jpeg") || low.endsWith(".png") || low.endsWith(".webp") || low.endsWith(".gif") || low.endsWith(".avif")) return base;
        String m = normalizeMime(mime);
        if (m.contains("png")) return base + ".png";
        if (m.contains("webp")) return base + ".webp";
        if (m.contains("gif")) return base + ".gif";
        if (m.contains("avif")) return base + ".avif";
        return base + ".jpg";
    }

    private static String normalizeMime(String mime) {
        if (mime == null) return "image/jpeg";
        String m = mime.toLowerCase(Locale.US).trim();
        int semi = m.indexOf(';');
        if (semi >= 0) m = m.substring(0, semi).trim();
        return m.isEmpty() ? "image/jpeg" : m;
    }

    private static boolean looksLikeImage(File f, String mime) {
        byte[] h = new byte[24];
        try (FileInputStream in = new FileInputStream(f)) {
            int n = in.read(h);
            if (n < 3) return false;
            String m = normalizeMime(mime);
            if (m.contains("jpeg") || m.contains("jpg")) return (h[0]&255)==0xFF && (h[1]&255)==0xD8 && (h[2]&255)==0xFF;
            if (m.contains("png")) return n>=8 && (h[0]&255)==0x89 && h[1]=='P' && h[2]=='N' && h[3]=='G';
            if (m.contains("gif")) return h[0]=='G' && h[1]=='I' && h[2]=='F';
            if (m.contains("webp")) return n>=12 && h[0]=='R' && h[1]=='I' && h[2]=='F' && h[3]=='F' && h[8]=='W' && h[9]=='E' && h[10]=='B' && h[11]=='P';
            if (m.contains("avif")) return n>=12 && h[4]=='f' && h[5]=='t' && h[6]=='y' && h[7]=='p';
            return f.length() > 512;
        } catch (Exception e) { return false; }
    }

    private SharedPreferences prefs() { return getSharedPreferences("state", MODE_PRIVATE); }

    private void setState(String state, String current) {
        prefs().edit().putString("service_status", state)
                .putString("current", current == null ? "-" : current)
                .putLong("last_state_at", System.currentTimeMillis()).apply();
    }

    private void stopWithReason(String state, String current, boolean returnCurrentToPending) {
        if (!active && currentItem == null) {
            setState(state, current);
            stopSelf();
            return;
        }
        if (returnCurrentToPending && currentItem != null) {
            db.returnToPending(currentItem.id, state);
        }
        AppLog.d(this, "SERVICE stop state=" + state + " current=" + current);
        setState(state, current);
        finishService(true);
    }

    private void finishService(boolean stopWebLoading) {
        active = false;
        if (stopWebLoading && webView != null) {
            try { webView.stopLoading(); } catch (Exception ignored) {}
        }
        resetTransferState(true);
        releaseWakeLock();
        CellularNetwork.unbindProcess(this);
        stopForeground(STOP_FOREGROUND_DETACH);
        stopSelf();
    }

    private void acquireWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) return;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WhiskyDownloader:WebViewDirect");
        wakeLock.setReferenceCounted(false);
        wakeLock.acquire();
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (Exception ignored) {}
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Image downloads", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Persistent cellular WebView image download queue");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    private void startAsForeground(String text) {
        Notification n = notification(text);
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        else startForeground(NOTIFICATION_ID, n);
    }

    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent pause = new Intent(this, DownloadService.class).setAction(ACTION_PAUSE);
        PendingIntent pPause = PendingIntent.getService(this, 1, pause, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("Whisky LTE Downloader v0.3")
                .setContentText(text)
                .setContentIntent(pi)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "Pause", pPause).build())
                .build();
    }

    private void updateNotification(String override) {
        String text = override;
        if (text == null) {
            QueueDb.Stats s = db.stats();
            text = String.format(Locale.US, "%,d / %,d · %s · WebView", s.counts[QueueDb.DONE], s.total(), humanBytes(s.bytes));
        }
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIFICATION_ID, notification(text));
    }

    private static String humanBytes(long b) {
        double v=b; String[] u={"B","KB","MB","GB","TB"}; int i=0;
        while(v>=1024 && i<u.length-1){v/=1024;i++;}
        return String.format(Locale.US,"%.1f %s",v,u[i]);
    }

    private static String trim(String s, int n) { return s == null || s.length() <= n ? s : s.substring(0, n); }
    private static String nullToDash(String s) { return s == null || s.trim().isEmpty() ? "-" : s; }

    @Override public void onTimeout(int startId, int fgsType) {
        AppLog.d(this, "SERVICE Android FGS timeout");
        stopWithReason("PAUSED BY ANDROID FGS TIMEOUT", "-", true);
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onDestroy() {
        active = false;
        resetTransferState(true);
        releaseWakeLock();
        CellularNetwork.unbindProcess(this);
        if (webView != null) {
            WebView v = webView;
            webView = null;
            main.post(() -> {
                try { v.stopLoading(); v.removeJavascriptInterface("AndroidBridge"); v.destroy(); } catch (Exception ignored) {}
            });
        }
        if (db != null) db.close();
        networkWorker.shutdownNow();
        CookieManager.getInstance().flush();
        AppLog.d(this, "SERVICE v0.3 destroyed");
        super.onDestroy();
    }
}
