package com.sinsa.whiskydownloader;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.InputStream;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_IMPORT = 10;
    private QueueDb db;
    private TextView status;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Runnable refreshTask = new Runnable() {
        @Override public void run() { refresh(); handler.postDelayed(this, 1500); }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        db = new QueueDb(this);
        db.recoverInterrupted();
        AppLog.d(this, "APP opened version=0.2.0");
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
        setContentView(buildUi());
    }

    private View buildUi() {
        int p = dp(18);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(p,p,p,p);
        ScrollView scroll = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);

        TextView title = new TextView(this);
        title.setText("Whisky LTE Downloader v0.2");
        title.setTextSize(26);
        title.setPadding(0,0,0,dp(12));
        body.addView(title);

        status = new TextView(this);
        status.setTextSize(16);
        status.setTextIsSelectable(true);
        body.addView(status, new LinearLayout.LayoutParams(-1, -2));

        body.addView(button("1. Import URL TXT", v -> importTxt()));
        body.addView(button("2. Open first pending URL in auth browser", v -> openAuth()));
        body.addView(button("3. Start / Resume on cellular", v -> startDownload()));
        body.addView(button("Pause after current file", v -> pauseDownload()));
        body.addView(button("VIEW DIAGNOSTIC LOG", v -> startActivity(new Intent(this, LogActivity.class))));
        body.addView(button("Retry FAILED + SKIPPED", v -> { db.retryFailedAndSkipped(); refresh(); }));
        body.addView(button("Battery optimization settings", v -> openBatterySettings()));
        body.addView(button("CLEAR QUEUE", v -> { db.clearAll(); AppLog.d(this, "QUEUE cleared by user"); refresh(); }));

        TextView note = new TextView(this);
        note.setPadding(0, dp(16), 0, 0);
        note.setText("v0.2 diagnostics\n• The exact pause reason is preserved.\n• HTTP code, MIME, cookie presence and first error preview are written to downloader.log.\n• Auth browser refuses to open until a queue exists, then loads the first real image URL.\n• If the first native request still returns 403 after the WebView itself displays the image, the cookie-sharing architecture is not sufficient for this host; the log will make that explicit.");
        body.addView(note);

        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        return root;
    }

    private Button button(String text, View.OnClickListener listener) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52)); lp.topMargin = dp(8); b.setLayoutParams(lp); return b;
    }

    private void importTxt() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("text/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i, REQ_IMPORT);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_IMPORT && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData(); status.setText("Importing URLs…");
            io.execute(() -> {
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    long n = db.importUrls(in); AppLog.d(this, "IMPORT completed new_urls=" + n + " uri=" + uri);
                    runOnUiThread(() -> { Toast.makeText(this, "Imported " + n + " new URLs", Toast.LENGTH_LONG).show(); refresh(); });
                } catch (Exception e) {
                    AppLog.d(this, "IMPORT failed " + e); runOnUiThread(() -> Toast.makeText(this, "Import failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
                }
            });
        }
    }

    private void openAuth() {
        if (db.firstPendingUrlOrNull() == null) { Toast.makeText(this, "No pending URL. Import URLs first.", Toast.LENGTH_LONG).show(); return; }
        startActivity(new Intent(this, AuthActivity.class));
    }

    private void startDownload() {
        getSharedPreferences("state", MODE_PRIVATE).edit().putBoolean("paused", false).remove("pause_reason").apply();
        AppLog.d(this, "UI Start/Resume pressed");
        Intent i = new Intent(this, DownloadService.class).setAction(DownloadService.ACTION_START);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            getSharedPreferences("state", MODE_PRIVATE).edit().putString("service_status", "START REQUESTED").apply();
            refresh();
        } catch (Exception e) {
            AppLog.d(this, "UI start service failed " + e);
            Toast.makeText(this, "Start failed: " + e.getClass().getSimpleName() + ": " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void pauseDownload() {
        getSharedPreferences("state", MODE_PRIVATE).edit().putBoolean("paused", true).putString("pause_reason", "PAUSED BY USER").apply();
        AppLog.d(this, "UI Pause pressed");
        try { startService(new Intent(this, DownloadService.class).setAction(DownloadService.ACTION_PAUSE)); } catch (Exception ignored) {}
    }

    private void openBatterySettings() {
        try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); }
        catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
    }

    private long freeBytes() {
        try {
            File base = getExternalFilesDir(Environment.DIRECTORY_PICTURES); if (base == null) base = getFilesDir();
            return new StatFs(base.getAbsolutePath()).getAvailableBytes();
        } catch (Exception e) { return -1; }
    }

    private void refresh() {
        QueueDb.Stats s = db.stats(); long total = s.total(); long done = s.counts[QueueDb.DONE]; double pct = total == 0 ? 0 : (100.0 * done / total);
        String serviceState = getSharedPreferences("state", MODE_PRIVATE).getString("service_status", "IDLE");
        String current = getSharedPreferences("state", MODE_PRIVATE).getString("current", "-");
        boolean authCookie = getSharedPreferences("state", MODE_PRIVATE).getBoolean("auth_cookie_present", false);
        long free = freeBytes();
        status.setText(String.format(Locale.US,
                "Service: %s\nTotal: %,d\nDone: %,d (%.2f%%)\nPending: %,d\nProcessing: %,d\nRetry: %,d\nSkipped: %,d\nFailed: %,d\nDownloaded: %s\nFree storage: %s\nAuth cookie present: %s\nCurrent: %s\nLatest DB error: %s",
                serviceState, total, done, pct, s.counts[QueueDb.PENDING], s.counts[QueueDb.PROCESSING], s.counts[QueueDb.RETRY],
                s.counts[QueueDb.SKIPPED], s.counts[QueueDb.FAILED], humanBytes(s.bytes), free < 0 ? "?" : humanBytes(free), authCookie, current, db.latestError()));
    }

    private static String humanBytes(long b) { double v=b; String[] u={"B","KB","MB","GB","TB"}; int i=0; while(v>=1024 && i<u.length-1){v/=1024;i++;} return String.format(Locale.US, "%.2f %s", v, u[i]); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    @Override protected void onResume() { super.onResume(); handler.post(refreshTask); }
    @Override protected void onPause() { handler.removeCallbacks(refreshTask); super.onPause(); }
    @Override protected void onDestroy() { io.shutdownNow(); db.close(); super.onDestroy(); }
}
