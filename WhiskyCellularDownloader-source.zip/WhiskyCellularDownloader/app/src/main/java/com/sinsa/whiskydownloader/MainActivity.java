package com.sinsa.whiskydownloader;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_IMPORT = 10;
    private QueueDb db;
    private TextView status;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Runnable refreshTask = new Runnable() {
        @Override public void run() {
            refresh();
            handler.postDelayed(this, 1500);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        db = new QueueDb(this);
        db.recoverInterrupted();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
        setContentView(buildUi());
    }

    private View buildUi() {
        int p = dp(18);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(p,p,p,p);
        ScrollView scroll = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);

        TextView title = new TextView(this);
        title.setText("Whisky LTE Downloader");
        title.setTextSize(26);
        title.setPadding(0,0,0,dp(12));
        body.addView(title);

        status = new TextView(this);
        status.setTextSize(16);
        status.setTextIsSelectable(true);
        body.addView(status, new LinearLayout.LayoutParams(-1, -2));

        body.addView(button("1. Import URL TXT", v -> importTxt()));
        body.addView(button("2. Open authentication browser", v -> startActivity(new Intent(this, AuthActivity.class))));
        body.addView(button("3. Start / Resume on cellular", v -> startDownload()));
        body.addView(button("Pause after current file", v -> pauseDownload()));
        body.addView(button("Retry FAILED + SKIPPED", v -> { db.retryFailedAndSkipped(); refresh(); }));
        body.addView(button("Battery optimization settings", v -> openBatterySettings()));
        body.addView(button("CLEAR QUEUE", v -> { db.clearAll(); refresh(); }));

        TextView note = new TextView(this);
        note.setPadding(0, dp(16), 0, 0);
        note.setText("Notes\n• URLs are streamed into SQLite; 330k entries do not need to fit in RAM.\n• PROCESSING rows are returned to PENDING on app restart.\n• Downloads are attempted through Android cellular transport. To require 4G specifically, set the phone's preferred network mode to LTE.\n• Authentication is manual in the visible WebView. This build does not implement Cloudflare bypass or undetected_chromedriver.\n• Files are saved under this app's external Pictures/WhiskyCrawler directory.");
        body.addView(note);

        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        return root;
    }

    private Button button(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.topMargin = dp(8);
        b.setLayoutParams(lp);
        return b;
    }

    private void importTxt() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("text/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, REQ_IMPORT);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_IMPORT && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            status.setText("Importing URLs…");
            io.execute(() -> {
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    long n = db.importUrls(in);
                    runOnUiThread(() -> { Toast.makeText(this, "Imported " + n + " new URLs", Toast.LENGTH_LONG).show(); refresh(); });
                } catch (Exception e) {
                    runOnUiThread(() -> Toast.makeText(this, "Import failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
                }
            });
        }
    }

    private void startDownload() {
        getSharedPreferences("state", MODE_PRIVATE).edit().putBoolean("paused", false).apply();
        Intent i = new Intent(this, DownloadService.class).setAction(DownloadService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }

    private void pauseDownload() {
        getSharedPreferences("state", MODE_PRIVATE).edit().putBoolean("paused", true).apply();
        startService(new Intent(this, DownloadService.class).setAction(DownloadService.ACTION_PAUSE));
    }

    private void openBatterySettings() {
        try {
            Intent i = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
            startActivity(i);
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private void refresh() {
        QueueDb.Stats s = db.stats();
        long total = s.total();
        long done = s.counts[QueueDb.DONE];
        double pct = total == 0 ? 0 : (100.0 * done / total);
        String serviceState = getSharedPreferences("state", MODE_PRIVATE).getString("service_status", "IDLE");
        String current = getSharedPreferences("state", MODE_PRIVATE).getString("current", "-");
        status.setText(String.format(Locale.US,
                "Service: %s\nTotal: %,d\nDone: %,d (%.2f%%)\nPending: %,d\nProcessing: %,d\nRetry: %,d\nSkipped: %,d\nFailed: %,d\nDownloaded: %s\nCurrent: %s",
                serviceState, total, done, pct,
                s.counts[QueueDb.PENDING], s.counts[QueueDb.PROCESSING], s.counts[QueueDb.RETRY],
                s.counts[QueueDb.SKIPPED], s.counts[QueueDb.FAILED], humanBytes(s.bytes), current));
    }

    private static String humanBytes(long b) {
        double v = b;
        String[] u = {"B","KB","MB","GB","TB"};
        int i=0; while(v>=1024 && i<u.length-1){v/=1024;i++;}
        return String.format(Locale.US, "%.2f %s", v, u[i]);
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onResume() { super.onResume(); handler.post(refreshTask); }
    @Override protected void onPause() { handler.removeCallbacks(refreshTask); super.onPause(); }
    @Override protected void onDestroy() { io.shutdownNow(); db.close(); super.onDestroy(); }
}
