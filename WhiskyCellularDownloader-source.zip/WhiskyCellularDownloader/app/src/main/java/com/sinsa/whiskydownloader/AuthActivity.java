package com.sinsa.whiskydownloader;

import android.app.Activity;
import android.graphics.Color;
import android.net.Network;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class AuthActivity extends Activity {
    private WebView webView;
    private TextView networkState;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        networkState = new TextView(this);
        networkState.setPadding(dp(12), dp(10), dp(12), dp(10));
        networkState.setText("Binding browser to cellular…");
        root.addView(networkState);

        Button done = new Button(this);
        done.setText("Authentication complete — save cookies and return");
        done.setAllCaps(false);
        done.setOnClickListener(v -> {
            CookieManager.getInstance().flush();
            if (webView != null) {
                getSharedPreferences("state", MODE_PRIVATE).edit()
                        .putString("user_agent", webView.getSettings().getUserAgentString())
                        .putLong("auth_saved_at", System.currentTimeMillis())
                        .apply();
            }
            Toast.makeText(this, "Cookies saved. You can resume the queue.", Toast.LENGTH_LONG).show();
            finish();
        });
        root.addView(done, new LinearLayout.LayoutParams(-1, dp(52)));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        if (android.os.Build.VERSION.SDK_INT >= 21) cm.setAcceptThirdPartyCookies(webView, true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        new Thread(() -> {
            try {
                Network n = CellularNetwork.bindProcess(this, 20);
                runOnUiThread(() -> {
                    if (n == null) {
                        networkState.setText("No cellular network found. Enable mobile data and retry.");
                    } else {
                        networkState.setText("CELLULAR bound. Complete any site verification below.");
                        QueueDb db = new QueueDb(this);
                        String target = db.firstPendingUrl();
                        db.close();
                        webView.loadUrl(target);
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> networkState.setText("Cellular bind failed: " + e.getMessage()));
            }
        }, "auth-cellular-bind").start();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        CookieManager.getInstance().flush();
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
