package com.sinsa.whiskydownloader;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Network;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class AuthActivity extends Activity {
    private WebView webView;
    private TextView networkState;
    private String target;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        AppLog.d(this, "AUTH activity opened");
        QueueDb initialDb = new QueueDb(this);
        target = initialDb.firstPendingUrlOrNull();
        initialDb.close();
        if (target == null) {
            Toast.makeText(this, "No pending URL. Import URLs first.", Toast.LENGTH_LONG).show();
            AppLog.d(this, "AUTH aborted: no pending URL");
            finish();
            return;
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        networkState = new TextView(this);
        networkState.setPadding(dp(12), dp(10), dp(12), dp(10));
        networkState.setText("Binding browser to cellular…\nTarget: " + target);
        networkState.setTextIsSelectable(true);
        root.addView(networkState);

        Button done = new Button(this);
        done.setText("Authentication complete — save cookies and return");
        done.setAllCaps(false);
        done.setOnClickListener(v -> {
            CookieManager.getInstance().flush();
            String ua = webView == null ? "" : webView.getSettings().getUserAgentString();
            String cookie = CookieManager.getInstance().getCookie(target);
            getSharedPreferences("state", MODE_PRIVATE).edit()
                    .putString("user_agent", ua)
                    .putLong("auth_saved_at", System.currentTimeMillis())
                    .putBoolean("auth_cookie_present", cookie != null && !cookie.isEmpty())
                    .apply();
            AppLog.d(this, "AUTH saved target=" + target + " cookie_present=" + (cookie != null && !cookie.isEmpty()) + " ua=" + ua);
            Toast.makeText(this, "Browser session saved. cookie_visible=" + (cookie != null && !cookie.isEmpty()), Toast.LENGTH_LONG).show();
            finish();
        });
        root.addView(done, new LinearLayout.LayoutParams(-1, dp(52)));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        if (android.os.Build.VERSION.SDK_INT >= 21) cm.setAcceptThirdPartyCookies(webView, true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
                AppLog.d(AuthActivity.this, "AUTH page started " + url);
            }
            @Override public void onPageFinished(WebView view, String url) {
                String cookie = CookieManager.getInstance().getCookie(url);
                networkState.setText("CELLULAR bound. Wait until the actual image is visible, then tap the button above.\nLoaded: " + url + "\nCookie present: " + (cookie != null && !cookie.isEmpty()));
                AppLog.d(AuthActivity.this, "AUTH page finished " + url + " title=" + view.getTitle() + " cookie_present=" + (cookie != null && !cookie.isEmpty()));
            }
        });
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        new Thread(() -> {
            try {
                Network n = CellularNetwork.bindProcess(this, 20);
                runOnUiThread(() -> {
                    if (n == null) {
                        networkState.setText("No cellular network found. Enable mobile data and retry.");
                        AppLog.d(this, "AUTH no cellular network");
                    } else {
                        networkState.setText("CELLULAR bound. Loading first pending URL…\n" + target);
                        AppLog.d(this, "AUTH cellular bound, loading " + target);
                        webView.loadUrl(target);
                    }
                });
            } catch (Exception e) {
                AppLog.d(this, "AUTH cellular bind failed: " + e);
                runOnUiThread(() -> networkState.setText("Cellular bind failed: " + e.getMessage()));
            }
        }, "auth-cellular-bind").start();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        CookieManager.getInstance().flush();
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        CellularNetwork.unbindProcess(this);
        AppLog.d(this, "AUTH activity closed");
        super.onDestroy();
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
