# Whisky LTE Downloader v0.3

Android sideload proof-of-concept for a very large queue of direct image URLs, designed around a **single persistent Android WebView/Chromium session**.

## Why v0.3 exists

Testing v0.2 showed the key behavior:

- The direct Whiskybase image URL eventually displays successfully inside Android WebView.
- The separate native `HttpURLConnection` request receives Cloudflare HTTP 403.

v0.3 therefore removes the native protected-image downloader. The URL is loaded by WebView itself, and after the page becomes an image document, JavaScript running inside that **same WebView session** reads the image bytes and transfers them to Android in 48 KiB chunks.

This build does not automate or bypass verification challenges. If verification is needed and does not resolve on its own, the queue pauses and asks the user to open the visible authentication browser.

## v0.3 flow

1. Import one URL per line into SQLite (hundreds of thousands are streamed, not loaded into RAM).
2. Open the first pending URL in the visible authentication browser.
3. Wait until the actual image is visible and tap **Authentication complete**.
4. Start the WebView-direct foreground service.
5. The service binds the app process to a cellular network and creates one persistent off-screen WebView.
6. Each queued URL is navigated in that same browser session.
7. A challenge/interstitial gets up to 60 seconds to resolve.
8. Once the document is recognized as an image, the app requests the bytes from Chromium cache/session (`only-if-cached`, then `force-cache`).
9. If cache/session extraction is unavailable, canvas extraction of the already-displayed image is the fallback.
10. Bytes are written to `.part`, validated, atomically renamed, and the URL is committed `DONE` in SQLite.

## Queue / restart semantics

Statuses remain per URL:

- PENDING
- PROCESSING
- DONE
- SKIPPED
- RETRY
- FAILED

At process start, stale PROCESSING rows are returned to PENDING. A killed app may leave a `.part`, but a URL is only marked DONE after the final image is fully written and validated.

## Output sharding

A single Android directory with 333k files is undesirable. v0.3 stores up to 5,000 files per shard:

`Android/data/com.sinsa.whiskydownloader/files/Pictures/WhiskyCrawler/0000/...`

`Android/data/com.sinsa.whiskydownloader/files/Pictures/WhiskyCrawler/0001/...`

and so on.

## Diagnostics

The main screen reports:

- Service state
- Engine/network
- Browser stage
- Last browser HTTP/MIME observation
- Extraction mode (`fetch-only-if-cached`, `fetch-force-cache`, or `canvas-fallback`)
- Queue counters
- Free storage
- Current URL
- Latest DB error

`VIEW DIAGNOSTIC LOG` shows the rotating `downloader.log` (up to 5 MiB).

## Important Android caveat

The foreground service owns an off-screen WebView. This is intentionally a proof-of-concept because Android/WebView background throttling behavior varies by device/OEM. A partial wake lock keeps the CPU available, but the device still needs field testing with the screen off and while other apps are foregrounded. If the off-screen browser stops progressing, the SQLite queue remains safe and the app can resume later.

## Build

- compileSdk 35
- targetSdk 34 (private sideload test build)
- Java 17
- Android Gradle Plugin 8.6.1

The existing DTRe workflow can build this ZIP after it is uploaded as `WhiskyCellularDownloader-source.zip`.
