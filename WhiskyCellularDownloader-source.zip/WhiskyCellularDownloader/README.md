# Whisky LTE Downloader v0.1

Private Android sideload project for a very large list of direct image URLs.

## What this build implements

- Streaming TXT import (tested by design for hundreds of thousands of lines; it never calls `readLines()`).
- SQLite persistent queue with per-URL state: PENDING / PROCESSING / DONE / SKIPPED / RETRY / FAILED.
- Crash/restart recovery: stale PROCESSING rows return to PENDING on launch.
- Visible Android WebView for user-completed site authentication; WebView cookies and User-Agent are reused by the downloader.
- Cellular transport request via Android `NetworkRequest(TRANSPORT_CELLULAR)`.
- Single-worker sequential downloading for conservative, long-running behavior.
- MIME validation plus basic file-signature validation.
- `.part` file followed by rename after a successful complete download.
- Retry/backoff for 429, 5xx, timeouts/network failures; max 5 retries.
- 403/503 or HTML challenge-like responses pause the whole queue and require user action in the visible browser.
- Foreground service notification and partial wake lock.
- Automatic pause below 5 GiB of free storage.
- App target SDK 34 for private sideload use. Android 15 adds a 6-hour/24-hour timeout to `dataSync` foreground services for apps targeting API 35+, so this v0.1 intentionally does not target 35.

## Important limitation

This is **not undetected_chromedriver (UC)**. UC depends on a desktop Chromium/ChromeDriver model and is not directly embeddable as a normal self-contained Android ARM64 APK. This project does not implement browser-fingerprint evasion or automated Cloudflare challenge bypass. Authentication is completed by the user in the visible WebView. The downloader then reuses the resulting cookies/User-Agent; whether a particular site accepts that second HTTP client is site-specific.

For `static.whiskybase.com`, first install the build and test the ten supplied URLs before importing the full 330k list. If the site binds its verification to browser-only properties beyond cookies/User-Agent, the native downloader will pause with `AUTH REQUIRED` instead of incorrectly marking the remaining queue as skipped.

## Input format

One direct URL per line. Empty lines and lines beginning with `#` are ignored. Duplicate URLs are ignored by the SQLite UNIQUE constraint.

See `sample_urls.txt`.

## Output

Files are written to the app-specific external directory:

`Android/data/com.sinsa.whiskydownloader/files/Pictures/WhiskyCrawler/`

Each file name is prefixed with the SQLite ID, e.g.:

`000000001_144629-big.jpg`

The database is stored in the app's private data directory. Do not uninstall the app until the queue state is no longer needed.

## Build

Requirements:

- Android Studio with Android SDK 35 installed
- JDK 17+
- Internet access for the first Gradle/Android plugin sync

Open this folder in Android Studio and choose **Build > Build APK(s)**. The resulting debug APK is normally under:

`app/build/outputs/apk/debug/app-debug.apk`

This source bundle does not contain downloaded Android SDK/Gradle binaries.

## Recommended first test

1. Keep mobile data enabled. If you require LTE specifically instead of 5G, select LTE/4G as the preferred network mode in Android system settings; Android's public app API exposes cellular transport, not a reliable unprivileged LTE-only selector.
2. Import `sample_urls.txt`.
3. Tap **Open authentication browser** and complete any normal verification shown by the site.
4. Tap **Authentication complete — save cookies and return**.
5. Tap **Start / Resume on cellular**.
6. Confirm that DONE rises and files appear in the output directory.
7. Only after this passes should you import the full 330k list.

## Queue semantics

The queue commits each URL independently. Pausing waits for the current image to finish. Killing the process during a file leaves a `.part`; on the next run the queue row is recovered and that URL is attempted again. Final files are only marked DONE after complete write and validation.

## GitHub Actions

A ready-to-run workflow is included at `.github/workflows/android-build.yml`. Push the project to GitHub and run **Build Android APK**; the workflow uploads `WhiskyLTEDownloader-debug` as an Actions artifact.
