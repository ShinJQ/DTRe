package com.sinsa.whiskydownloader;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.provider.MediaStore;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Shared, version-stable output storage.
 *
 * Android 10+ writes through MediaStore into:
 *   /storage/emulated/0/Download/WhiskyCrawler/<stable-bucket>/<original-name>
 *
 * The bucket is derived from Whiskybase's numeric image id (id / 5000), not the
 * SQLite queue row id, so the same URL maps to the same public path after app
 * updates, queue re-imports, or a fresh database. This also keeps directories
 * comfortably below a few thousand files for the current 333k URL corpus.
 */
public final class SharedOutputStore {
    public static final String ROOT_RELATIVE = Environment.DIRECTORY_DOWNLOADS + "/WhiskyCrawler/";
    public static final String DISPLAY_ROOT = "/storage/emulated/0/Download/WhiskyCrawler/";
    private static final Pattern LEADING_ID = Pattern.compile("^(\\d+)");

    private final Context context;
    private final ContentResolver resolver;

    public SharedOutputStore(Context context) {
        this.context = context.getApplicationContext();
        this.resolver = this.context.getContentResolver();
    }

    public Target targetFor(String url) throws Exception {
        String path = new URL(url).getPath();
        String base = path.substring(path.lastIndexOf('/') + 1);
        base = safeName(base.isEmpty() ? "image.jpg" : base);

        String bucket;
        Matcher m = LEADING_ID.matcher(base);
        if (m.find()) {
            long imageId;
            try { imageId = Long.parseLong(m.group(1)); }
            catch (NumberFormatException e) { imageId = Math.abs((long)url.hashCode()); }
            bucket = String.format(Locale.US, "%04d", imageId / 5000L);
        } else {
            bucket = String.format(Locale.US, "h%03x", url.hashCode() & 0x0fff);
        }
        String relativeDir = ROOT_RELATIVE + bucket + "/";
        return new Target(relativeDir, base, relativeDir + base);
    }

    public long freeBytes() {
        try {
            File root = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            return new StatFs(root.getAbsolutePath()).getAvailableBytes();
        } catch (Throwable t) {
            try { return new StatFs(context.getFilesDir().getAbsolutePath()).getAvailableBytes(); }
            catch (Throwable ignored) { return -1L; }
        }
    }

    public boolean hasAnyExisting() {
        if (Build.VERSION.SDK_INT >= 29) {
            String[] projection = new String[]{MediaStore.MediaColumns._ID};
            String selection = MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?";
            try (Cursor c = resolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI, projection, selection,
                    new String[]{ROOT_RELATIVE + "%"}, null)) {
                return c != null && c.moveToFirst();
            } catch (Throwable ignored) { return false; }
        }
        File root = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "WhiskyCrawler");
        File[] children = root.listFiles();
        return children != null && children.length > 0;
    }

    /** Find an already finalized shared file at exactly the deterministic target path. */
    public Existing findExisting(Target target) {
        if (Build.VERSION.SDK_INT >= 29) {
            Uri collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            String[] projection = new String[]{
                    MediaStore.MediaColumns._ID,
                    MediaStore.MediaColumns.SIZE,
                    MediaStore.MediaColumns.MIME_TYPE
            };
            String selection = MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " +
                    MediaStore.MediaColumns.RELATIVE_PATH + "=?";
            try (Cursor c = resolver.query(collection, projection, selection,
                    new String[]{target.displayName, target.relativeDir}, null)) {
                if (c != null) {
                    while (c.moveToNext()) {
                        long size = c.isNull(1) ? 0L : c.getLong(1);
                        if (size > 0) {
                            Uri uri = ContentUris.withAppendedId(collection, c.getLong(0));
                            String mime = c.isNull(2) ? mimeFromName(target.displayName) : c.getString(2);
                            return new Existing(uri, size, mime, target.dbPath);
                        }
                    }
                }
            } catch (Throwable ignored) {}
            return null;
        }

        File f = legacyPublicFile(target);
        return f.isFile() && f.length() > 0
                ? new Existing(Uri.fromFile(f), f.length(), mimeFromName(target.displayName), target.dbPath)
                : null;
    }

    public Pending create(Target target, String mime) throws IOException {
        mime = normalizeMime(mime, target.displayName);
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, target.displayName);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, target.relativeDir);
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (uri == null) throw new IOException("MediaStore insert returned null for " + target.dbPath);
            try {
                OutputStream raw = resolver.openOutputStream(uri, "w");
                if (raw == null) throw new IOException("MediaStore openOutputStream returned null");
                return new Pending(target, uri, new BufferedOutputStream(raw, 128 * 1024), null, null, mime);
            } catch (Throwable t) {
                try { resolver.delete(uri, null, null); } catch (Throwable ignored) {}
                if (t instanceof IOException) throw (IOException)t;
                throw new IOException("Cannot open MediaStore output: " + t.getMessage(), t);
            }
        }

        File finalFile = legacyPublicFile(target);
        File dir = finalFile.getParentFile();
        if (dir == null || (!dir.exists() && !dir.mkdirs())) throw new IOException("Cannot create " + dir);
        File part = new File(dir, target.displayName + ".part");
        //noinspection ResultOfMethodCallIgnored
        part.delete();
        return new Pending(target, Uri.fromFile(finalFile),
                new BufferedOutputStream(new FileOutputStream(part), 128 * 1024), part, finalFile, mime);
    }

    public void finalizePending(Pending pending) throws IOException {
        if (pending == null) return;
        if (Build.VERSION.SDK_INT >= 29 && pending.filePart == null) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.IS_PENDING, 0);
            int n = resolver.update(pending.uri, cv, null, null);
            if (n <= 0) throw new IOException("MediaStore finalize failed for " + pending.target.dbPath);
            pending.finalized = true;
            return;
        }
        if (pending.filePart == null || pending.fileFinal == null) throw new IOException("Missing legacy output files");
        if (pending.fileFinal.exists() && !pending.fileFinal.delete()) throw new IOException("Cannot replace " + pending.fileFinal);
        if (!pending.filePart.renameTo(pending.fileFinal)) throw new IOException("Atomic rename failed for " + pending.fileFinal);
        pending.finalized = true;
    }

    public void abort(Pending pending) {
        if (pending == null || pending.finalized) return;
        try { pending.out.close(); } catch (Throwable ignored) {}
        if (Build.VERSION.SDK_INT >= 29 && pending.filePart == null) {
            try { resolver.delete(pending.uri, null, null); } catch (Throwable ignored) {}
        } else if (pending.filePart != null) {
            //noinspection ResultOfMethodCallIgnored
            pending.filePart.delete();
        }
    }

    /** Copy one old app-private v0.1-v0.5 image into the shared deterministic store. */
    public Existing copyLegacyFile(File source, Target target, String mime) throws IOException {
        Existing existing = findExisting(target);
        if (existing != null) return existing;
        Pending pending = create(target, mime);
        byte[] buf = new byte[256 * 1024];
        long written = 0L;
        try (java.io.FileInputStream in = new java.io.FileInputStream(source)) {
            int n;
            while ((n = in.read(buf)) >= 0) {
                if (n == 0) continue;
                pending.out.write(buf, 0, n);
                written += n;
            }
            pending.out.flush();
            pending.out.close();
            finalizePending(pending);
            return new Existing(pending.uri, written, pending.mime, target.dbPath);
        } catch (Throwable t) {
            abort(pending);
            if (t instanceof IOException) throw (IOException)t;
            throw new IOException("Legacy copy failed: " + t.getMessage(), t);
        }
    }

    private File legacyPublicFile(Target target) {
        File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        String suffix = target.relativeDir.substring((Environment.DIRECTORY_DOWNLOADS + "/").length());
        return new File(new File(downloads, suffix), target.displayName);
    }

    public static String normalizeMime(String mime, String name) {
        if (mime != null) {
            String m = mime.toLowerCase(Locale.US).trim();
            int semi = m.indexOf(';');
            if (semi >= 0) m = m.substring(0, semi).trim();
            if (m.startsWith("image/")) return m;
        }
        return mimeFromName(name);
    }

    public static String mimeFromName(String name) {
        String n = name == null ? "" : name.toLowerCase(Locale.US);
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".webp")) return "image/webp";
        if (n.endsWith(".gif")) return "image/gif";
        if (n.endsWith(".avif")) return "image/avif";
        return "image/jpeg";
    }

    private static String safeName(String name) {
        String out = name.replaceAll("[^A-Za-z0-9._-]", "_");
        if (out.length() > 160) out = out.substring(out.length() - 160);
        return out.isEmpty() ? "image.jpg" : out;
    }

    public static final class Target {
        public final String relativeDir;
        public final String displayName;
        public final String dbPath;
        Target(String relativeDir, String displayName, String dbPath) {
            this.relativeDir = relativeDir;
            this.displayName = displayName;
            this.dbPath = dbPath;
        }
    }

    public static final class Existing {
        public final Uri uri;
        public final long size;
        public final String mime;
        public final String dbPath;
        Existing(Uri uri, long size, String mime, String dbPath) {
            this.uri = uri;
            this.size = size;
            this.mime = mime;
            this.dbPath = dbPath;
        }
    }

    public static final class Pending {
        public final Target target;
        public final Uri uri;
        public final BufferedOutputStream out;
        final File filePart;
        final File fileFinal;
        final String mime;
        boolean finalized;
        Pending(Target target, Uri uri, BufferedOutputStream out, File filePart, File fileFinal, String mime) {
            this.target = target;
            this.uri = uri;
            this.out = out;
            this.filePart = filePart;
            this.fileFinal = fileFinal;
            this.mime = mime;
        }
    }
}
