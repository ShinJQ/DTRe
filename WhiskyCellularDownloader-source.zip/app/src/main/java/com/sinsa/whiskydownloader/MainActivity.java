package com.sinsa.whiskydownloader;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_IMPORT = 10;
    private QueueDb db;
    private SharedOutputStore outputStore;
    private TextView status;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private boolean autoAuthLaunchedForCurrentChallenge;
    private final Runnable refreshTask = new Runnable() {
        @Override public void run() { refresh(); handler.postDelayed(this, 1500); }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        db = new QueueDb(this);
        outputStore = new SharedOutputStore(this);
        db.recoverInterrupted();
        if (db.stats().total() == 0 && outputStore.hasAnyExisting()) {
            getSharedPreferences("state", MODE_PRIVATE).edit().putBoolean("dedupe_scan_required", true).apply();
        }
        getSharedPreferences("state", MODE_PRIVATE).edit().putString("output_path", SharedOutputStore.DISPLAY_ROOT).apply();
        AppLog.d(this, "APP opened version=0.11.0");
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
        if (Build.VERSION.SDK_INT <= 28 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 101);
        }
        setContentView(buildUi());
    }

    private View buildUi() {
        int p = dp(18);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(p,p,p,p);
        ScrollView scroll = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);

        TextView title = new TextView(this);
        title.setText("Whisky LTE Downloader v0.11");
        title.setTextSize(26);
        title.setPadding(0,0,0,dp(12));
        body.addView(title);

        status = new TextView(this);
        status.setTextSize(16);
        status.setTextIsSelectable(true);
        body.addView(status, new LinearLayout.LayoutParams(-1, -2));

        body.addView(button("1. Import URL TXT", v -> importTxt()));
        body.addView(button("2. Open first pending URL in auth browser", v -> openAuth()));
        body.addView(button("3. Enable background WebView overlay", v -> requestOverlayPermission()));
        body.addView(button("4. Start / Resume adaptive WebView on cellular", v -> startDownload()));
        body.addView(button("Pause after current file", v -> pauseDownload()));
        body.addView(button("VIEW DIAGNOSTIC LOG", v -> startActivity(new Intent(this, LogActivity.class))));
        body.addView(button("Retry FAILED + SKIPPED", v -> { db.retryFailedAndSkipped(); refresh(); }));
        body.addView(button("Battery optimization settings", v -> openBatterySettings()));
        body.addView(button("CLEAR QUEUE (downloaded files stay)", v -> {
            // Stop any in-memory PROCESSING item before deleting rows. Otherwise a service that
            // already owns currentItem can continue operating on a ghost row after the DB is cleared.
            try { stopService(new Intent(this, DownloadService.class)); } catch (Throwable ignored) {}
            handler.postDelayed(() -> {
                db.clearAll();
                getSharedPreferences("state", MODE_PRIVATE).edit()
                        .putBoolean("dedupe_scan_required", true)
                        .remove("current_target_url").remove("current_target_id")
                        .remove("auth_target_url").remove("auth_target_id").remove("auth_reason")
                        .putBoolean("resume_after_auth", false)
                        .putString("service_status", "IDLE / QUEUE CLEARED")
                        .apply();
                AppLog.d(this, "QUEUE cleared by user after stopping service; shared files retained");
                refresh();
            }, 300L);
        }));

        TextView note = new TextView(this);
        note.setPadding(0, dp(16), 0, 0);
        note.setText("v0.11 hard local-first dedupe + exact-target recovery + persistent shared storage\n• Output: /storage/emulated/0/Download/WhiskyCrawler/<stable bucket>/<original image name>.\n• The bucket is derived from the Whiskybase image id, not the SQLite queue id, so app updates keep the same target path.\n• Existing v0.1-v0.5 app-private DONE files are migrated to the shared Downloads tree on first v0.6 service start.\n• Before EVERY network/browser request, the deterministic shared target is checked locally first. Existing files are marked DONE with zero Whiskybase request.\n• Prefetch is adaptive (1–8 ahead): repeated fallbacks reduce pressure; sustained fast hits raise it gradually.\n• After a real verification page, prefetch restarts cautiously and ramps up.\n• Cloudflare verification triggers conservative automatic cooldown/retry before asking for manual verification.\n• If navigation makes no progress twice in a row, the service stops the loop and automatically opens button 2 for the exact stalled URL.\n• If manual verification is still required, the auth browser opens automatically for the exact blocked target.\n• HTTP 200 application/octet-stream image responses are accepted only after image magic-byte validation (JPEG/PNG/GIF/WebP/AVIF).\n• Auth completion is accepted only after the exact target image is loaded; then it saves and resumes automatically without another tap.\n• ETA uses recent end-to-end completion throughput and is shown with estimated finish time.\n• The app does not solve/click verification challenges; any interactive verification remains user-completed.");
        body.addView(note);

        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        return root;
    }

    private Button button(String text, View.OnClickListener listener) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52)); lp.topMargin = dp(8); b.setLayoutParams(lp); return b;
    }

    private void importTxt() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("text/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i, REQ_IMPORT);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_IMPORT && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData(); status.setText("Importing URLs…");
            io.execute(() -> {
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    long n = db.importUrls(in); AppLog.d(this, "IMPORT completed new_urls=" + n + " uri=" + uri);
                    runOnUiThread(() -> { Toast.makeText(this, "Imported " + n + " new URLs", Toast.LENGTH_LONG).show(); refresh(); });
                } catch (Exception e) {
                    AppLog.d(this, "IMPORT failed " + e); runOnUiThread(() -> Toast.makeText(this, "Import failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
                }
            });
        }
    }

    private void openAuth() {
        android.content.SharedPreferences sp = getSharedPreferences("state", MODE_PRIVATE);
        String target = sp.getString("auth_target_url", null);
        if (target == null || target.trim().isEmpty()) target = sp.getString("current_target_url", null);
        if (target == null || target.trim().isEmpty()) target = db.firstPendingUrlOrNull();
        if (target == null) { Toast.makeText(this, "No pending URL. Import URLs first.", Toast.LENGTH_LONG).show(); return; }
        Intent i = new Intent(this, AuthActivity.class);
        i.putExtra(AuthActivity.EXTRA_TARGET_URL, target);
        startActivity(i);
    }

    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Background overlay permission already granted", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private void startDownload() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Grant Draw over other apps first, then tap Start again.", Toast.LENGTH_LONG).show();
            requestOverlayPermission();
            return;
        }
        getSharedPreferences("state", MODE_PRIVATE).edit().putBoolean("pause_requested", false).remove("pause_reason").apply();
        AppLog.d(this, "UI Start/Resume pressed");
        Intent i = new Intent(this, DownloadService.class).setAction(DownloadService.ACTION_START);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            getSharedPreferences("state", MODE_PRIVATE).edit().putString("service_status", "START REQUESTED").apply();
            refresh();
        } catch (Exception e) {
            AppLog.d(this, "UI start service failed " + e);
            Toast.makeText(this, "Start failed: " + e.getClass().getSimpleName() + ": " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void pauseDownload() {
        AppLog.d(this, "UI Pause pressed");
        try { startService(new Intent(this, DownloadService.class).setAction(DownloadService.ACTION_PAUSE)); } catch (Exception ignored) {}
    }

    private void openBatterySettings() {
        try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); }
        catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
    }

    private long freeBytes() {
        return outputStore == null ? -1L : outputStore.freeBytes();
    }

    private void refresh() {
        QueueDb.Stats s = db.stats();
        long total = s.total();
        long done = s.counts[QueueDb.DONE];
        double pct = total == 0 ? 0 : (100.0 * done / total);
        android.content.SharedPreferences sp = getSharedPreferences("state", MODE_PRIVATE);
        String serviceState = sp.getString("service_status", "IDLE");
        if (serviceState.startsWith("AUTH REQUIRED")) {
            if (!autoAuthLaunchedForCurrentChallenge) {
                autoAuthLaunchedForCurrentChallenge = true;
                AppLog.d(this, "UI auto-opening auth browser for pending verification");
                handler.postDelayed(() -> {
                    if (!isFinishing()) openAuth();
                }, 350L);
            }
        } else {
            autoAuthLaunchedForCurrentChallenge = false;
        }
        String current = sp.getString("current", "-");
        boolean authCookie = sp.getBoolean("auth_cookie_present", false);
        long free = freeBytes();
        double rate = sp.getFloat("eta_rate_ips", 0f);
        long etaSec = sp.getLong("eta_seconds", -1L);
        long finishAt = sp.getLong("eta_finish_at", 0L);
        int adaptive = sp.getInt("adaptive_prefetch", 1);
        String eta = formatEta(etaSec);
        String finish = finishAt > 0 ? new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date(finishAt)) : "warming up";
        status.setText(String.format(Locale.US,
                "Service: %s\nEngine: %s / %s\nOutput: %s\nBackground overlay: %s\nAdaptive prefetch: %d\nBrowser stage: %s\nBrowser HTTP/MIME: %d / %s\nExtract mode: %s\nSpeed: %.2f images/s (%,.0f/hour)\nETA: %s\nEstimated finish: %s\nTotal: %,d\nDone: %,d (%.2f%%)\nPending: %,d\nProcessing: %,d\nRetry: %,d\nSkipped: %,d\nFailed: %,d\nDownloaded: %s\nFree storage: %s\nCookie visible to WebView API: %s\nCurrent: %s\nLatest DB error: %s",
                serviceState,
                sp.getString("browser_engine", "WEBVIEW ADAPTIVE PREFETCH"),
                sp.getString("browser_network", "-"),
                sp.getString("output_path", SharedOutputStore.DISPLAY_ROOT),
                (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) ? "GRANTED" : "NOT GRANTED",
                adaptive,
                sp.getString("browser_stage", "-"),
                sp.getInt("browser_last_http", 0),
                sp.getString("browser_last_mime", "-"),
                sp.getString("browser_extract_mode", "-"),
                rate, rate * 3600.0, eta, finish,
                total, done, pct, s.counts[QueueDb.PENDING], s.counts[QueueDb.PROCESSING], s.counts[QueueDb.RETRY],
                s.counts[QueueDb.SKIPPED], s.counts[QueueDb.FAILED], humanBytes(s.bytes), free < 0 ? "?" : humanBytes(free), authCookie, current, db.latestError()));
    }

    private static String formatEta(long sec) {
        if (sec < 0) return "warming up";
        long d = sec / 86400L; sec %= 86400L;
        long h = sec / 3600L; sec %= 3600L;
        long m = sec / 60L;
        if (d > 0) return d + "d " + h + "h " + m + "m";
        if (h > 0) return h + "h " + m + "m";
        return m + "m";
    }

    private static String humanBytes(long b) { double v=b; String[] u={"B","KB","MB","GB","TB"}; int i=0; while(v>=1024 && i<u.length-1){v/=1024;i++;} return String.format(Locale.US, "%.2f %s", v, u[i]); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    @Override protected void onResume() { super.onResume(); handler.post(refreshTask); }
    @Override protected void onPause() { handler.removeCallbacks(refreshTask); super.onPause(); }
    @Override protected void onDestroy() { io.shutdownNow(); db.close(); super.onDestroy(); }
}
