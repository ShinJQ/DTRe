package com.sinsa.whiskydownloader;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Network;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class AuthActivity extends Activity {
    private WebView webView;
    private TextView networkState;
    private Button done;
    private String target;
    private boolean imageVerified;
    private boolean autoResumeScheduled;
    private boolean savedAndResumed;
    private final Handler authHandler = new Handler(Looper.getMainLooper());
    private final Runnable autoResumeRunnable = () -> {
        autoResumeScheduled = false;
        if (!savedAndResumed && imageVerified && !isFinishing()) saveAndResume();
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        AppLog.d(this, "AUTH activity opened");
        QueueDb initialDb = new QueueDb(this);
        target = initialDb.firstPendingUrlOrNull();
        initialDb.close();
        if (target == null) {
            Toast.makeText(this, "No pending URL. Import URLs first.", Toast.LENGTH_LONG).show();
            AppLog.d(this, "AUTH aborted: no pending URL");
            finish();
            return;
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        networkState = new TextView(this);
        networkState.setPadding(dp(12), dp(10), dp(12), dp(10));
        networkState.setText("Binding browser to cellular…\nTarget: " + target);
        networkState.setTextIsSelectable(true);
        root.addView(networkState);

        done = new Button(this);
        done.setText("Wait until the actual target image is verified…");
        done.setAllCaps(false);
        done.setEnabled(false);
        done.setOnClickListener(v -> saveAndResume());
        root.addView(done, new LinearLayout.LayoutParams(-1, dp(52)));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= 21) cm.setAcceptThirdPartyCookies(webView, true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
                imageVerified = false;
                autoResumeScheduled = false;
                authHandler.removeCallbacks(autoResumeRunnable);
                done.setEnabled(false);
                done.setText("Wait until the actual target image is verified…");
                AppLog.d(AuthActivity.this, "AUTH page started " + url);
            }

            @Override public void onPageFinished(WebView view, String url) {
                String cookie = CookieManager.getInstance().getCookie(url);
                networkState.setText("CELLULAR bound. Complete any visible verification.\nThe button enables only after the exact target image is loaded.\nLoaded: " + url + "\nCookie present: " + (cookie != null && !cookie.isEmpty()));
                AppLog.d(AuthActivity.this, "AUTH page finished " + url + " title=" + view.getTitle() + " cookie_present=" + (cookie != null && !cookie.isEmpty()));
                validateActualImage(url);
            }
        });
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        new Thread(() -> {
            try {
                Network n = CellularNetwork.bindProcess(this, 20);
                runOnUiThread(() -> {
                    if (n == null) {
                        networkState.setText("No cellular network found. Enable mobile data and retry.");
                        AppLog.d(this, "AUTH no cellular network");
                    } else {
                        networkState.setText("CELLULAR bound. Loading pending target…\n" + target);
                        AppLog.d(this, "AUTH cellular bound, loading " + target);
                        webView.loadUrl(target);
                    }
                });
            } catch (Exception e) {
                AppLog.d(this, "AUTH cellular bind failed: " + e);
                runOnUiThread(() -> networkState.setText("Cellular bind failed: " + e.getMessage()));
            }
        }, "auth-cellular-bind").start();
    }

    private void validateActualImage(String loadedUrl) {
        if (webView == null || target == null || !sameTarget(loadedUrl, target)) return;
        String js = "(function(){try{" +
                "var ct=(document.contentType||'').toLowerCase();var imgs=document.images||[];var im=imgs.length?imgs[0]:null;" +
                "var href=location.href||'';var one=!!(imgs.length===1&&im&&im.complete&&im.naturalWidth>0);" +
                "return (href===" + org.json.JSONObject.quote(target) + ") && (ct.indexOf('image/')===0 || one);" +
                "}catch(e){return false;}})();";
        try {
            webView.evaluateJavascript(js, value -> {
                boolean ok = "true".equals(value);
                imageVerified = ok;
                done.setEnabled(ok);
                if (ok) {
                    done.setText("Target image verified — resuming automatically…");
                    networkState.setText("Target image verified. The queue will resume automatically.\n" + target);
                    AppLog.d(AuthActivity.this, "AUTH target image verified " + target + " auto_resume_scheduled=true");
                    if (!autoResumeScheduled && !savedAndResumed) {
                        autoResumeScheduled = true;
                        authHandler.postDelayed(autoResumeRunnable, 900L);
                    }
                }
            });
        } catch (Throwable t) {
            AppLog.d(this, "AUTH validation failed " + t);
        }
    }

    private void saveAndResume() {
        if (savedAndResumed) return;
        if (!imageVerified) {
            Toast.makeText(this, "The target image is not verified yet.", Toast.LENGTH_LONG).show();
            return;
        }
        savedAndResumed = true;
        authHandler.removeCallbacks(autoResumeRunnable);
        CookieManager.getInstance().flush();
        String ua = webView == null ? "" : webView.getSettings().getUserAgentString();
        String cookie = CookieManager.getInstance().getCookie(target);
        getSharedPreferences("state", MODE_PRIVATE).edit()
                .putString("user_agent", ua)
                .putLong("auth_saved_at", System.currentTimeMillis())
                .putLong("auth_verified_at", System.currentTimeMillis())
                .putBoolean("auth_cookie_present", cookie != null && !cookie.isEmpty())
                .putBoolean("resume_after_auth", false)
                .putInt("adaptive_prefetch", 1)
                .putInt("challenge_auto_attempts", 0)
                .apply();
        AppLog.d(this, "AUTH saved verified target=" + target + " cookie_present=" + (cookie != null && !cookie.isEmpty()) + " ua=" + ua);
        Toast.makeText(this, "Verified browser session saved. Resuming cautiously…", Toast.LENGTH_LONG).show();

        Context app = getApplicationContext();
        Intent i = new Intent(app, DownloadService.class).setAction(DownloadService.ACTION_START);
        // Let this Activity finish and unbind its process-level cellular binding first; otherwise
        // onDestroy() could race with the service's new binding.
        finish();
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            try {
                if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(i); else app.startService(i);
            } catch (Throwable t) {
                AppLog.d(app, "AUTH auto-resume failed " + t);
            }
        }, 650L);
    }

    private static boolean sameTarget(String a, String b) {
        if (a == null || b == null) return false;
        int x = a.indexOf('#'); if (x >= 0) a = a.substring(0, x);
        int y = b.indexOf('#'); if (y >= 0) b = b.substring(0, y);
        return a.equals(b);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        authHandler.removeCallbacks(autoResumeRunnable);
        CookieManager.getInstance().flush();
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        CellularNetwork.unbindProcess(this);
        AppLog.d(this, "AUTH activity closed");
        super.onDestroy();
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
