package com.sinsa.whiskydownloader;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class LogActivity extends Activity {
    private TextView text;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(12), dp(12), dp(12));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        Button refresh = button("Refresh");
        refresh.setOnClickListener(v -> load());
        Button copy = button("Copy log");
        copy.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Whisky downloader log", AppLog.tail(this, 500)));
            Toast.makeText(this, "Copied last 500 log lines", Toast.LENGTH_SHORT).show();
        });
        bar.addView(refresh, new LinearLayout.LayoutParams(0, dp(48), 1));
        bar.addView(copy, new LinearLayout.LayoutParams(0, dp(48), 1));
        root.addView(bar);

        text = new TextView(this);
        text.setTextSize(12);
        text.setTextIsSelectable(true);
        text.setPadding(0, dp(8), 0, dp(8));
        ScrollView scroll = new ScrollView(this);
        scroll.addView(text);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        load();
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s); b.setAllCaps(false); b.setGravity(Gravity.CENTER);
        return b;
    }

    private void load() { text.setText(AppLog.tail(this, 500)); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
