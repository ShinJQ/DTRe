package com.sinsa.whiskydownloader;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.net.Network;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Base64;
import android.view.Gravity;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * v0.8 adaptive pipelined browser downloader with overlay-attached WebView, cache prefetch,
 * automatic conservative challenge cooldown/retry, and stall watchdog.
 *
 * Important design choice: every protected image is first loaded by Android WebView itself.
 * The app does NOT copy WebView cookies into HttpURLConnection.  After the image document is
 * visibly/semantically loaded, JavaScript running inside that same WebView reads the image bytes
 * from Chromium's cache/session and sends them to Java in small chunks.  If the cache fetch is not
 * available, a canvas copy is used as a last-resort fallback.
 *
 * Verification challenges are never solved or clicked automatically. If a verification page appears,
 * the service backs off and retries the same pending target conservatively. Persistent interactive
 * verification still requires the visible AuthActivity, but successful image verification resumes automatically.
 */
public class DownloadService extends Service {
    public static final String ACTION_START = "com.sinsa.whiskydownloader.START";
    public static final String ACTION_PAUSE = "com.sinsa.whiskydownloader.PAUSE";

    private static final String CHANNEL = "download";
    private static final int NOTIFICATION_ID = 7;
    private static final long MIN_FREE_BYTES = 512L * 1024 * 1024;
    private static final long CHALLENGE_WAIT_MS = 60_000L;
    private static final long PAGE_HARD_TIMEOUT_MS = 100_000L;
    private static final long INSPECT_INTERVAL_MS = 1_500L;
    private static final long BETWEEN_ITEMS_MS = 35L;
    private static final int PREFETCH_MIN = 1;
    private static final int PREFETCH_MAX = 8;
    private static final int PREFETCH_INITIAL = 6;
    private static final long FAST_PRELOAD_TIMEOUT_MS = 3_000L;
    private static final long PREFETCH_READY_WAIT_MS = 2_400L;
    private static final long WATCHDOG_INTERVAL_MS = 5_000L;
    private static final long STALL_THRESHOLD_MS = 15_000L;
    private static final int MAX_STALL_REKICKS = 2;
    private static final long AUTH_LAUNCH_DEBOUNCE_MS = 20_000L;
    private static final long EARLY_CHALLENGE_STOP_MS = 5_000L;
    private static final long AUTH_CAUTION_MS = 45_000L;
    private static final long[] CHALLENGE_AUTO_BACKOFF_MS = {90_000L, 180_000L, 300_000L};
    private static final int POST_CHALLENGE_STABLE_SUCCESSES = 20;
    private static final long ETA_WINDOW_MS = 180_000L;
    private static final int ETA_MAX_SAMPLES = 180;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService networkWorker = Executors.newSingleThreadExecutor();
    private final Object transferLock = new Object();

    private QueueDb db;
    private SharedOutputStore outputStore;
    private WebView webView;
    private PowerManager.WakeLock wakeLock;
    private WindowManager windowManager;
    private boolean overlayAttached;
    private volatile boolean active;
    private volatile boolean pauseAfterCurrent;

    private QueueDb.Item currentItem;
    private String currentToken;
    private long currentStartedAt;
    private int inspectCount;
    private volatile boolean extractionStarted;
    private volatile boolean fastSessionReady;
    private volatile boolean fastFetchInFlight;
    private volatile boolean currentWasFastPath;
    private int adaptivePrefetch = PREFETCH_INITIAL;
    private int adaptiveFastSuccessStreak;
    private int adaptiveFallbackDebt;
    private long cautiousUntilWall;
    private boolean dedupeScanRequired;
    private boolean checkFirstPendingForCrashRecovery = true;
    private long lastProgressAt;
    private long lastNotificationAt;
    private int challengeAutoAttempts;
    private int postChallengeSuccessStreak;
    private boolean challengeCooldownActive;
    private int stallRekickCount;
    private boolean authLaunchInFlight;
    private long lastAuthLaunchAt;

    private final Runnable challengeAutoRetry = () -> {
        if (!active || !challengeCooldownActive) return;
        challengeCooldownActive = false;
        fastSessionReady = false;
        adaptivePrefetch = PREFETCH_MIN;
        cautiousUntilWall = System.currentTimeMillis() + AUTH_CAUTION_MS;
        prefs().edit().putInt("adaptive_prefetch", adaptivePrefetch)
                .putString("browser_stage", "AUTO RETRY AFTER CHALLENGE").apply();
        AppLog.d(DownloadService.this, "AUTH auto-retry attempt=" + challengeAutoAttempts + " starting");
        setState("AUTO RETRY AFTER CHALLENGE", "attempt " + challengeAutoAttempts);
        startNext();
    };

    // ETA / throughput state. Completion timestamps measure end-to-end queue throughput,
    // including fast cache hits and full-navigation fallbacks.
    private final Deque<Long> completionTimes = new ArrayDeque<>();
    private long etaTotal;
    private long etaTerminal;
    private double etaRateIps;

    // Chunk transfer state. Access only inside synchronized(transferLock).
    private BufferedOutputStream currentOut;
    private SharedOutputStore.Pending currentPendingOutput;
    private SharedOutputStore.Target currentTarget;
    private final byte[] currentHeader = new byte[24];
    private int currentHeaderLen;
    private String currentMime;
    private String currentExtractMode;
    private int expectedChunks;
    private int receivedChunks;
    private long expectedBytes;
    private long receivedBytes;

    private final Runnable watchdog = new Runnable() {
        @Override public void run() {
            if (!active) return;
            try {
                if (currentItem != null) {
                    long idle = System.currentTimeMillis() - lastProgressAt;
                    if (idle >= STALL_THRESHOLD_MS) {
                        AppLog.d(DownloadService.this, "WATCHDOG stalled id=" + currentItem.id + " idle_ms=" + idle + " extraction=" + extractionStarted + " webUrl=" + (webView == null ? "-" : webView.getUrl()));
                        if (fastFetchInFlight && !extractionStarted) {
                            fallbackFastToNavigation("watchdog-fast-stall-" + idle + "ms");
                        } else if (extractionStarted || isTransferActive()) {
                            retryCurrent("Watchdog: WebView extraction/transfer stalled for " + (idle / 1000) + "s", 0, currentMime);
                        } else {
                            handleNavigationStall("watchdog-stall-" + idle + "ms");
                        }
                    }
                }
            } catch (Throwable t) {
                AppLog.d(DownloadService.this, "WATCHDOG exception " + t);
            } finally {
                if (active) main.postDelayed(this, WATCHDOG_INTERVAL_MS);
            }
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        db = new QueueDb(this);
        outputStore = new SharedOutputStore(this);
        db.recoverInterrupted();
        createChannel();
        AppLog.d(this, "SERVICE v0.8 created engine=octet-safe-stall-auth-auto-recovery-shared-output");
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        AppLog.d(this, "SERVICE command action=" + action + " active=" + active);

        if (ACTION_PAUSE.equals(action)) {
            pauseAfterCurrent = true;
            prefs().edit().putBoolean("pause_requested", true).apply();
            AppLog.d(this, "PAUSE requested; current item will be allowed to finish");
            if (!active || currentItem == null) {
                setState("PAUSED BY USER", "-");
                stopForeground(STOP_FOREGROUND_DETACH);
                stopSelf();
            } else {
                setState("PAUSE REQUESTED — FINISHING CURRENT", "#" + currentItem.id + " " + currentItem.url);
                updateNotification("Pause requested — finishing current image");
            }
            return START_NOT_STICKY;
        }

        startAsForeground("Starting browser-direct engine on cellular…");
        if (active) {
            pauseAfterCurrent = false;
            prefs().edit().putBoolean("pause_requested", false).apply();
            AppLog.d(this, "SERVICE already active; resume flag cleared; preserving in-flight work");
            main.post(() -> {
                if (webView != null) attachWebViewOverlay();
                if (currentItem == null) {
                    startNext();
                    return;
                }
                long idle = System.currentTimeMillis() - lastProgressAt;
                if (extractionStarted || fastFetchInFlight || isTransferActive() || idle < STALL_THRESHOLD_MS) {
                    AppLog.d(this, "BROWSER resume no-kick id=" + currentItem.id + " idle_ms=" + idle +
                            " extraction=" + extractionStarted + " fast=" + fastFetchInFlight + " transfer=" + isTransferActive());
                } else {
                    handleNavigationStall("manual-resume-stall-" + idle + "ms");
                }
            });
            return START_STICKY;
        }

        active = true;
        pauseAfterCurrent = false;
        initEtaAndAdaptive();
        dedupeScanRequired = prefs().getBoolean("dedupe_scan_required", false);
        prefs().edit()
                .putBoolean("pause_requested", false)
                .remove("pause_reason")
                .putString("browser_engine", "WEBVIEW ADAPTIVE PREFETCH + SHARED OUTPUT")
                .putString("output_path", SharedOutputStore.DISPLAY_ROOT)
                .apply();
        acquireWakeLock();
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            stopWithReason("BACKGROUND OVERLAY PERMISSION REQUIRED", "Enable Draw over other apps, then Start again", false);
            return START_STICKY;
        }
        setState("WAITING FOR CELLULAR", "-");
        lastProgressAt = System.currentTimeMillis();
        main.removeCallbacks(watchdog);
        main.removeCallbacks(challengeAutoRetry);
        challengeCooldownActive = false;
        main.postDelayed(watchdog, WATCHDOG_INTERVAL_MS);

        networkWorker.execute(() -> {
            try {
                migrateLegacyFiles();
                AppLog.d(this, "NETWORK binding whole app process to cellular");
                Network n = CellularNetwork.bindProcess(this, 30);
                if (n == null) {
                    main.post(() -> stopWithReason("NO CELLULAR NETWORK", "Enable mobile data and try again", false));
                    return;
                }
                AppLog.d(this, "NETWORK process bound to cellular " + n);
                main.post(() -> {
                    prefs().edit().putString("browser_network", "CELLULAR").apply();
                    ensureWebView();
                    startNext();
                });
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                main.post(() -> stopWithReason("INTERRUPTED", "Cellular binding interrupted", false));
            } catch (Throwable t) {
                AppLog.d(this, "NETWORK bind fatal " + t);
                main.post(() -> stopWithReason("NETWORK ERROR", t.getClass().getSimpleName() + ": " + t.getMessage(), false));
            }
        });
        return START_STICKY;
    }

    private void ensureWebView() {
        if (webView != null) return;
        try {
            webView = new WebView(this);
            WebSettings s = webView.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setDatabaseEnabled(true);
            s.setLoadsImagesAutomatically(true);
            s.setBlockNetworkImage(false);
            s.setCacheMode(WebSettings.LOAD_DEFAULT);
            if (Build.VERSION.SDK_INT >= 23) s.setOffscreenPreRaster(true);

            CookieManager cm = CookieManager.getInstance();
            cm.setAcceptCookie(true);
            if (Build.VERSION.SDK_INT >= 21) cm.setAcceptThirdPartyCookies(webView, true);

            webView.addJavascriptInterface(new BrowserBridge(), "AndroidBridge");
            webView.setWebViewClient(new WebViewClient() {
                @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                    if (currentItem == null) return;
                    if (!sameTarget(url, currentItem.url)) {
                        AppLog.d(DownloadService.this, "BROWSER stale pageStarted ignored current_id=" + currentItem.id + " observed=" + url + " expected=" + currentItem.url);
                        return;
                    }
                    touchProgress("PAGE STARTED");
                    AppLog.d(DownloadService.this, "BROWSER page started id=" + currentItem.id + " url=" + url);
                }

                @Override public void onPageFinished(WebView view, String url) {
                    if (currentItem == null) return;
                    if (!sameTarget(url, currentItem.url)) {
                        AppLog.d(DownloadService.this, "BROWSER stale pageFinished ignored current_id=" + currentItem.id + " observed=" + url + " expected=" + currentItem.url);
                        return;
                    }
                    stallRekickCount = 0;
                    touchProgress("PAGE FINISHED / INSPECTING");
                    AppLog.d(DownloadService.this, "BROWSER page finished id=" + currentItem.id + " url=" + url + " title=" + view.getTitle());
                    scheduleInspect(650L);
                }

                @Override public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse response) {
                    if (currentItem == null || request == null || !request.isForMainFrame()) return;
                    String observed = request.getUrl() == null ? null : request.getUrl().toString();
                    if (!sameTarget(observed, currentItem.url)) {
                        AppLog.d(DownloadService.this, "BROWSER stale HTTP ignored current_id=" + currentItem.id + " observed=" + observed + " expected=" + currentItem.url);
                        return;
                    }
                    touchProgress("HTTP OBSERVATION");
                    int code = response == null ? 0 : response.getStatusCode();
                    String mime = response == null ? null : response.getMimeType();
                    prefs().edit().putInt("browser_last_http", code).putString("browser_last_mime", nullToDash(mime)).apply();
                    AppLog.d(DownloadService.this, "BROWSER main HTTP id=" + currentItem.id + " http=" + code + " mime=" + mime + " url=" + request.getUrl());
                    // Do not pause here: Cloudflare may intentionally serve an HTML challenge first and
                    // then navigate to the image. The inspection watchdog decides after a grace period.
                    scheduleInspect(1_500L);
                }

                @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                    if (currentItem == null || request == null || !request.isForMainFrame()) return;
                    String observed = request.getUrl() == null ? null : request.getUrl().toString();
                    if (!sameTarget(observed, currentItem.url)) {
                        AppLog.d(DownloadService.this, "BROWSER stale error ignored current_id=" + currentItem.id + " observed=" + observed + " expected=" + currentItem.url);
                        return;
                    }
                    touchProgress("LOAD ERROR / WAITING");
                    String msg = error == null ? "unknown" : String.valueOf(error.getDescription());
                    AppLog.d(DownloadService.this, "BROWSER main error id=" + currentItem.id + " code=" + (error == null ? 0 : error.getErrorCode()) + " msg=" + msg);
                    scheduleInspect(2_000L);
                }
            });
            webView.setBackgroundColor(Color.TRANSPARENT);
            attachWebViewOverlay();
            try { webView.onResume(); webView.resumeTimers(); } catch (Throwable ignored) {}
            AppLog.d(this, "BROWSER overlay WebView initialized ua=" + s.getUserAgentString());
        } catch (Throwable t) {
            AppLog.d(this, "BROWSER initialization failed " + t);
            stopWithReason("WEBVIEW INIT ERROR", t.getClass().getSimpleName() + ": " + t.getMessage(), false);
        }
    }

    private void startNext() {
        if (!active) return;
        if (pauseAfterCurrent || prefs().getBoolean("pause_requested", false)) {
            stopWithReason("PAUSED BY USER", "-", false);
            return;
        }
        if (webView == null) {
            ensureWebView();
            if (webView == null) return;
        }

        long free = outputStore.freeBytes();
        prefs().edit().putLong("free_bytes", free).apply();
        if (free >= 0 && free < MIN_FREE_BYTES) {
            stopWithReason("PAUSED: LOW STORAGE", humanBytes(free) + " free at " + SharedOutputStore.DISPLAY_ROOT, false);
            return;
        }

        QueueDb.Item item = db.claimNext();
        if (item == null) {
            QueueDb.Stats stats = db.stats();
            if (stats.counts[QueueDb.RETRY] > 0) {
                setState("WAITING FOR RETRY", "-");
                main.postDelayed(this::startNext, 5_000L);
                return;
            }
            setState("IDLE / QUEUE COMPLETE", "-");
            prefs().edit().putBoolean("dedupe_scan_required", false).putLong("eta_seconds", 0L).putLong("eta_finish_at", System.currentTimeMillis()).apply();
            AppLog.d(this, "QUEUE complete total=" + stats.total());
            finishService(false);
            return;
        }

        if (dedupeScanRequired || checkFirstPendingForCrashRecovery) {
            checkFirstPendingForCrashRecovery = false;
            try {
                SharedOutputStore.Target target = outputStore.targetFor(item.url);
                SharedOutputStore.Existing existing = outputStore.findExisting(target);
                if (existing != null) {
                    db.markDone(item.id, existing.dbPath, existing.size, 200, existing.mime);
                    markTerminalWithoutNetworkSample();
                    AppLog.d(this, "STORAGE existing hit id=" + item.id + " bytes=" + existing.size + " file=" + existing.dbPath);
                    prefs().edit().putString("browser_stage", "EXISTING FILE / NO DOWNLOAD").apply();
                    main.postDelayed(this::startNext, 5L);
                    return;
                }
            } catch (Throwable t) {
                AppLog.d(this, "STORAGE existing check failed id=" + item.id + " " + t);
            }
        }

        currentItem = item;
        currentToken = UUID.randomUUID().toString();
        currentStartedAt = System.currentTimeMillis();
        lastProgressAt = currentStartedAt;
        inspectCount = 0;
        extractionStarted = false;
        fastFetchInFlight = false;
        currentWasFastPath = false;
        stallRekickCount = 0;
        authLaunchInFlight = false;
        resetTransferState(true);

        prefs().edit()
                .putString("current_target_url", item.url)
                .putLong("current_target_id", item.id)
                .putInt("browser_last_http", 0)
                .putString("browser_last_mime", "-")
                .putString("browser_extract_mode", "-")
                .apply();

        if (fastSessionReady && isWhiskyOrigin(webView.getUrl()) && isWhiskyOrigin(item.url)) {
            startFastCachedPath(item.id, currentToken);
        } else {
            navigateCurrent("anchor-navigation");
        }
    }

    /**
     * Fast path: keep the already-authorized same-origin WebView document alive.  The next URLs are
     * prefetched as normal image subresources (which Chromium may load in parallel), then each queue
     * item is read back from Chromium's same-origin cache without a top-level page navigation.
     */
    private void startFastCachedPath(long id, String token) {
        if (!isCurrent(id, token) || webView == null) return;
        fastFetchInFlight = true;
        currentWasFastPath = true;
        extractionStarted = false;
        setState("FAST CACHE/PREFETCH", "#" + id + " " + currentItem.url);
        prefs().edit().putString("browser_stage", "FAST CACHE/PREFETCH").apply();
        AppLog.d(this, "FAST start id=" + id + " url=" + currentItem.url);

        String js = "(async function(){" +
                "const T='" + token + "',ID=" + id + ",TARGET=" + org.json.JSONObject.quote(currentItem.url) + ";" +
                "function sendBytes(u8,mime,mode){" +
                " const C=49152,total=Math.ceil(u8.length/C);" +
                " AndroidBridge.onBegin(T,ID,mime||'image/jpeg',u8.length,total,mode);" +
                " for(let i=0;i<total;i++){let a=i*C,b=Math.min(u8.length,a+C),bin='';" +
                "  for(let j=a;j<b;j+=8192){let e=Math.min(b,j+8192);bin+=String.fromCharCode.apply(null,u8.slice(j,e));}" +
                "  AndroidBridge.onChunk(T,ID,i,btoa(bin));}" +
                " AndroidBridge.onComplete(T,ID);}" +
                "async function fromCache(mode){try{" +
                " const r=await fetch(TARGET,{credentials:'include',cache:'only-if-cached',mode:'same-origin'});" +
                " const ct=(r.headers.get('content-type')||'').split(';')[0].toLowerCase();" +
                " const ext=/\\.(jpe?g|png|webp|gif|avif)(?:$|[?#])/i.test(TARGET);" +
                " const byteImage=r.ok&&(ct.indexOf('image/')===0||ct==='application/octet-stream'||(!ct&&ext));" +
                " if(byteImage){sendBytes(new Uint8Array(await r.arrayBuffer()),ct||'application/octet-stream',mode);return true;}" +
                " AndroidBridge.onFetchObservation(T,ID,r.status,ct,mode+' non-image/cache-miss');return false;" +
                "}catch(e){AndroidBridge.onFetchObservation(T,ID,0,'',mode+' '+String(e));return false;}}" +
                "function entry(){return window.__wcdPrefetch&&window.__wcdPrefetch[TARGET];}" +
                "async function waitEntry(e,ms){if(!e)return 'none';const st=Date.now();while(Date.now()-st<ms){if(e.state==='loaded'||e.state==='error')return e.state;await new Promise(r=>setTimeout(r,40));}return e.state||'timeout';}" +
                "function startOne(){window.__wcdPrefetch=window.__wcdPrefetch||{};let e={state:'loading',started:Date.now(),img:null};let im=new Image();e.img=im;im.decoding='async';im.onload=()=>{e.state='loaded';e.ended=Date.now();};im.onerror=()=>{e.state='error';e.ended=Date.now();};window.__wcdPrefetch[TARGET]=e;im.src=TARGET;return e;}" +
                "try{" +
                " if(await fromCache('prefetch-cache-hit'))return;" +
                " let e=entry();" +
                " if(e&&e.state==='loading')await waitEntry(e," + PREFETCH_READY_WAIT_MS + ");" +
                " if(e&&e.state==='loaded'&&await fromCache('prefetch-ready-cache'))return;" +
                " if(!e||e.state==='error'){e=startOne();await waitEntry(e," + FAST_PRELOAD_TIMEOUT_MS + ");}" +
                " else if(e.state!=='loaded'){await waitEntry(e," + FAST_PRELOAD_TIMEOUT_MS + ");}" +
                " if(e&&(e.state==='loaded'||e.state==='error')&&await fromCache(e.state==='loaded'?'subresource-preload-cache':'subresource-error-cache'))return;" +
                " AndroidBridge.onFastFetchFailure(T,ID,(e&&e.state==='loaded')?'preload completed but cache extraction failed':'image preload failed/not ready');" +
                "}catch(e){AndroidBridge.onFastFetchFailure(T,ID,String(e));}" +
                "})();";
        try {
            webView.evaluateJavascript(js, null);
            prefetchUpcoming();
        } catch (Throwable t) {
            fallbackFastToNavigation("fast-js-injection-" + t.getClass().getSimpleName());
        }
    }

    private void prefetchUpcoming() {
        if (!active || webView == null || !fastSessionReady || !isWhiskyOrigin(webView.getUrl())) return;
        int window = effectivePrefetchWindow();
        List<QueueDb.Item> next = db.peekNext(window);
        if (next.isEmpty()) return;
        StringBuilder a = new StringBuilder("[");
        for (int i=0;i<next.size();i++) {
            if (i>0) a.append(',');
            a.append(org.json.JSONObject.quote(next.get(i).url));
        }
        a.append(']');
        String js = "(function(){try{" +
                "const U=" + a + ";window.__wcdPrefetch=window.__wcdPrefetch||{};" +
                "for(const k of Object.keys(window.__wcdPrefetch)){if(U.indexOf(k)<0){try{let e=window.__wcdPrefetch[k];if(e&&e.img)e.img.src='';}catch(e){} delete window.__wcdPrefetch[k];}}" +
                "for(const u of U){if(!window.__wcdPrefetch[u]){let e={state:'loading',started:Date.now(),img:null};let im=new Image();e.img=im;im.decoding='async';im.onload=()=>{e.state='loaded';e.ended=Date.now();};im.onerror=()=>{e.state='error';e.ended=Date.now();};window.__wcdPrefetch[u]=e;im.src=u;}}" +
                "}catch(e){}})();";
        try {
            webView.evaluateJavascript(js, null);
            prefs().edit().putInt("adaptive_prefetch", adaptivePrefetch).putString("browser_stage", "PREFETCH WINDOW " + next.size() + " / adaptive " + adaptivePrefetch).apply();
        } catch (Throwable ignored) {}
    }

    private void cleanupPrefetch(String url) {
        if (webView == null || url == null) return;
        String js = "(function(){try{const u=" + org.json.JSONObject.quote(url) + ";if(window.__wcdPrefetch&&window.__wcdPrefetch[u]){let e=window.__wcdPrefetch[u];if(e&&e.img)e.img.src='';delete window.__wcdPrefetch[u];}}catch(e){}})();";
        try { webView.evaluateJavascript(js, null); } catch (Throwable ignored) {}
    }

    private void fallbackFastToNavigation(String reason) {
        if (!active || currentItem == null || webView == null) return;
        if (!fastFetchInFlight && currentWasFastPath == false) return;
        fastFetchInFlight = false;
        currentWasFastPath = false;
        extractionStarted = false;
        adaptiveOnFallback(reason);
        AppLog.d(this, "FAST fallback id=" + currentItem.id + " reason=" + reason + " adaptive_window=" + adaptivePrefetch);
        navigateCurrent("fast-fallback:" + reason);
    }

    private void navigateCurrent(String reason) {
        if (!active || currentItem == null || webView == null) return;
        QueueDb.Item item = currentItem;
        fastFetchInFlight = false;
        currentWasFastPath = false;
        extractionStarted = false;
        currentStartedAt = System.currentTimeMillis();
        lastProgressAt = currentStartedAt;
        inspectCount = 0;
        setState("BROWSER LOADING", "#" + item.id + " " + item.url);
        prefs().edit().putString("browser_stage", "NAVIGATING: " + reason).apply();
        AppLog.d(this, "BROWSER load id=" + item.id + " retry=" + item.retryCount + " reason=" + reason + " url=" + item.url);
        try {
            webView.stopLoading();
            webView.loadUrl(item.url);
            final long id = item.id;
            final String token = currentToken;
            main.postDelayed(() -> {
                if (!isCurrent(id, token) || extractionStarted || fastFetchInFlight) return;
                long elapsed = System.currentTimeMillis() - currentStartedAt;
                AppLog.d(this, "BROWSER hard-timeout id=" + id + " elapsed_ms=" + elapsed);
                authRequired("Browser did not become an image document within " + (elapsed / 1000) + "s");
            }, PAGE_HARD_TIMEOUT_MS);
        } catch (Throwable t) {
            AppLog.d(this, "BROWSER load exception id=" + item.id + " " + t);
            retryCurrent("WebView load exception: " + t.getClass().getSimpleName() + ": " + t.getMessage(), 0, null);
        }
    }

    private boolean isWhiskyOrigin(String url) {
        if (url == null) return false;
        try { return "static.whiskybase.com".equalsIgnoreCase(new URL(url).getHost()); }
        catch (Exception e) { return false; }
    }

    private void scheduleInspect(long delayMs) {
        if (!active || currentItem == null || extractionStarted) return;
        final long id = currentItem.id;
        final String token = currentToken;
        main.postDelayed(() -> {
            if (!isCurrent(id, token) || extractionStarted) return;
            inspectCurrent(id, token);
        }, delayMs);
    }

    private void inspectCurrent(long id, String token) {
        if (!isCurrent(id, token) || webView == null || extractionStarted) return;
        String observed = webView.getUrl();
        if (!sameTarget(observed, currentItem.url)) {
            AppLog.d(this, "BROWSER inspect deferred id=" + id + " observed=" + observed + " expected=" + currentItem.url);
            scheduleInspect(INSPECT_INTERVAL_MS);
            return;
        }
        inspectCount++;
        String js = "(function(){try{" +
                "var ct=(document.contentType||'').toLowerCase();" +
                "var imgs=document.images||[];var img=imgs.length?imgs[0]:null;" +
                "var txt=((document.body&&document.body.innerText)||'').trim();" +
                "var href=location.href||'';" +
                "var ext=/\\.(jpe?g|png|webp|gif|avif)(?:$|[?#])/i.test(href);" +
                "var one=!!(imgs.length===1&&img&&img.complete&&img.naturalWidth>0);" +
                "var imageLike=(ct.indexOf('image/')===0)||(ext&&one&&txt.length<64);" +
                "AndroidBridge.onInspect('" + token + "'," + id + ",imageLike,ct,(document.title||''),imgs.length,(img&&img.currentSrc)||'',href,txt.substring(0,220));" +
                "}catch(e){AndroidBridge.onInspectError('" + token + "'," + id + ",String(e));}})();";
        try {
            webView.evaluateJavascript(js, null);
        } catch (Throwable t) {
            AppLog.d(this, "BROWSER inspect evaluate failed id=" + id + " " + t);
            retryCurrent("WebView inspect failed: " + t.getMessage(), 0, null);
        }
    }

    private void beginExtraction(long id, String token) {
        if (!isCurrent(id, token) || extractionStarted || webView == null) return;
        extractionStarted = true;
        setState("EXTRACTING IN WEBVIEW", "#" + id + " " + currentItem.url);
        prefs().edit().putString("browser_stage", "EXTRACTING").apply();
        AppLog.d(this, "BROWSER extract start id=" + id + " using cache/session; canvas fallback enabled");

        // All protected network access below is executed by this same Chromium/WebView session.
        // The first fetch asks Chromium for an already cached same-origin response.  If unavailable,
        // force-cache is tried.  A canvas copy of the already displayed image is the final fallback.
        String js = "(async function(){" +
                "const T='" + token + "',ID=" + id + ",TARGET=" + org.json.JSONObject.quote(currentItem.url) + ";" +
                "if(location.href!==TARGET){AndroidBridge.onExtractFailure(T,ID,'URL mismatch before extraction: '+location.href);return;}" +
                "function sendBytes(u8,mime,mode){" +
                " const C=49152,total=Math.ceil(u8.length/C);" +
                " AndroidBridge.onBegin(T,ID,mime||'image/jpeg',u8.length,total,mode);" +
                " for(let i=0;i<total;i++){let a=i*C,b=Math.min(u8.length,a+C),bin='';" +
                "   for(let j=a;j<b;j+=8192){let e=Math.min(b,j+8192);bin+=String.fromCharCode.apply(null,u8.slice(j,e));}" +
                "   AndroidBridge.onChunk(T,ID,i,btoa(bin));}" +
                " AndroidBridge.onComplete(T,ID);}" +
                "async function tryFetch(cacheMode){try{" +
                " const r=await fetch(location.href,{credentials:'include',cache:cacheMode,mode:'same-origin'});" +
                " const ct=(r.headers.get('content-type')||'').split(';')[0].toLowerCase();" +
                " const ext=/\\.(jpe?g|png|webp|gif|avif)(?:$|[?#])/i.test(location.href);" +
                " const byteImage=r.ok&&(ct.indexOf('image/')===0||ct==='application/octet-stream'||(!ct&&ext));" +
                " if(byteImage){sendBytes(new Uint8Array(await r.arrayBuffer()),ct||'application/octet-stream','fetch-'+cacheMode);return true;}" +
                " AndroidBridge.onFetchObservation(T,ID,r.status,ct,'fetch-'+cacheMode);return false;" +
                "}catch(e){AndroidBridge.onFetchObservation(T,ID,0,'',cacheMode+': '+String(e));return false;}}" +
                "try{" +
                " if(await tryFetch('only-if-cached'))return;" +
                " if(await tryFetch('force-cache'))return;" +
                " const imgs=document.images||[];const img=imgs.length?imgs[0]:null;" +
                " if(!img||!img.complete||!img.naturalWidth){AndroidBridge.onExtractFailure(T,ID,'No loaded image element for canvas fallback');return;}" +
                " const cv=document.createElement('canvas');cv.width=img.naturalWidth;cv.height=img.naturalHeight;" +
                " const cx=cv.getContext('2d');cx.drawImage(img,0,0);" +
                " const mime=((document.contentType||'image/jpeg').toLowerCase().indexOf('png')>=0)?'image/png':'image/jpeg';" +
                " const blob=await new Promise((resolve,reject)=>cv.toBlob(b=>b?resolve(b):reject(new Error('canvas toBlob failed')),mime,1.0));" +
                " sendBytes(new Uint8Array(await blob.arrayBuffer()),mime,'canvas-fallback');" +
                "}catch(e){AndroidBridge.onExtractFailure(T,ID,String(e));}" +
                "})();";
        try {
            webView.evaluateJavascript(js, null);
        } catch (Throwable t) {
            extractionStarted = false;
            retryCurrent("Extraction injection failed: " + t.getMessage(), 0, null);
        }
    }

    private final class BrowserBridge {
        @JavascriptInterface public void onInspect(String token, long id, boolean imageLike, String contentType,
                                                   String title, int imageCount, String currentSrc, String href, String textPreview) {
            if (!isCurrent(id, token)) return;
            if (!sameTarget(href, currentItem.url) || (imageLike && currentSrc != null && !currentSrc.isEmpty() && !sameTarget(currentSrc, currentItem.url))) {
                AppLog.d(DownloadService.this, "BROWSER stale inspect ignored id=" + id + " href=" + href + " src=" + currentSrc + " expected=" + currentItem.url);
                main.post(() -> scheduleInspect(INSPECT_INTERVAL_MS));
                return;
            }
            touchProgress("INSPECT CALLBACK");
            long elapsed = System.currentTimeMillis() - currentStartedAt;
            if (inspectCount == 1 || inspectCount % 5 == 0 || imageLike) {
                AppLog.d(DownloadService.this, "BROWSER inspect id=" + id + " image=" + imageLike + " ct=" + contentType +
                        " images=" + imageCount + " elapsed_ms=" + elapsed + " title=" + trim(title, 120) +
                        " text=" + trim(textPreview, 180));
            }
            prefs().edit().putString("browser_last_mime", nullToDash(contentType)).apply();
            if (imageLike) {
                main.post(() -> beginExtraction(id, token));
            } else if (looksLikeVerificationPage(contentType, title, textPreview) && elapsed >= EARLY_CHALLENGE_STOP_MS) {
                main.post(() -> authRequired("Verification page detected. title=" + trim(title, 100)));
            } else if (elapsed >= CHALLENGE_WAIT_MS) {
                main.post(() -> authRequired("Verification page still present after " + (elapsed / 1000) + "s. title=" + trim(title, 100)));
            } else {
                main.post(() -> scheduleInspect(INSPECT_INTERVAL_MS));
            }
        }

        @JavascriptInterface public void onInspectError(String token, long id, String error) {
            if (!isCurrent(id, token)) return;
            touchProgress("INSPECT JS ERROR");
            AppLog.d(DownloadService.this, "BROWSER inspect JS error id=" + id + " " + error);
            main.post(() -> scheduleInspect(INSPECT_INTERVAL_MS));
        }

        @JavascriptInterface public void onFetchObservation(String token, long id, int status, String mime, String detail) {
            if (!isCurrent(id, token)) return;
            touchProgress("EXTRACT OBSERVATION");
            AppLog.d(DownloadService.this, "BROWSER extract observation id=" + id + " http=" + status + " mime=" + mime + " detail=" + detail);
            prefs().edit().putInt("browser_last_http", status).putString("browser_last_mime", nullToDash(mime)).apply();
        }

        @JavascriptInterface public void onFastFetchFailure(String token, long id, String error) {
            if (!isCurrent(id, token)) return;
            touchProgress("FAST FALLBACK");
            main.post(() -> fallbackFastToNavigation(error == null ? "unknown" : error));
        }

        @JavascriptInterface public void onBegin(String token, long id, String mime, long totalBytes, int chunks, String mode) {
            if (!isCurrent(id, token)) return;
            extractionStarted = true;
            fastFetchInFlight = false;
            touchProgress("TRANSFER BEGIN");
            synchronized (transferLock) {
                try {
                    resetTransferStateLocked(true);
                    currentTarget = outputStore.targetFor(currentItem.url);
                    currentMime = SharedOutputStore.normalizeMime(mime, currentTarget.displayName);
                    currentPendingOutput = outputStore.create(currentTarget, currentMime);
                    currentOut = currentPendingOutput.out;
                    currentHeaderLen = 0;
                    currentExtractMode = mode == null ? "unknown" : mode;
                    expectedChunks = chunks;
                    expectedBytes = totalBytes;
                    receivedChunks = 0;
                    receivedBytes = 0;
                    prefs().edit().putString("browser_extract_mode", currentExtractMode).putString("browser_stage", "TRANSFERRING BYTES").apply();
                    AppLog.d(DownloadService.this, "TRANSFER begin id=" + id + " bytes=" + totalBytes + " chunks=" + chunks + " mime=" + currentMime + " mode=" + currentExtractMode);
                } catch (Throwable t) {
                    AppLog.d(DownloadService.this, "TRANSFER begin failed id=" + id + " " + t);
                    main.post(() -> retryCurrent("Transfer begin failed: " + t.getMessage(), 0, mime));
                }
            }
        }

        @JavascriptInterface public void onChunk(String token, long id, int index, String base64) {
            if (!isCurrent(id, token)) return;
            synchronized (transferLock) {
                if (currentOut == null) return;
                try {
                    if (index != receivedChunks) throw new IOException("Chunk order mismatch expected=" + receivedChunks + " got=" + index);
                    byte[] b = Base64.decode(base64, Base64.DEFAULT);
                    if (currentHeaderLen < currentHeader.length) {
                        int n = Math.min(currentHeader.length - currentHeaderLen, b.length);
                        System.arraycopy(b, 0, currentHeader, currentHeaderLen, n);
                        currentHeaderLen += n;
                    }
                    currentOut.write(b);
                    receivedBytes += b.length;
                    receivedChunks++;
                    lastProgressAt = System.currentTimeMillis();
                    if (receivedChunks % 25 == 0) {
                        prefs().edit().putString("browser_stage", "TRANSFERRING " + receivedChunks + "/" + expectedChunks).apply();
                    }
                } catch (Throwable t) {
                    AppLog.d(DownloadService.this, "TRANSFER chunk failed id=" + id + " index=" + index + " " + t);
                    closeCurrentOutLocked();
                    main.post(() -> retryCurrent("Chunk transfer failed: " + t.getMessage(), 0, currentMime));
                }
            }
        }

        @JavascriptInterface public void onComplete(String token, long id) {
            if (!isCurrent(id, token)) return;
            touchProgress("TRANSFER COMPLETE");
            synchronized (transferLock) {
                try {
                    if (currentOut == null || currentPendingOutput == null || currentTarget == null) throw new IOException("Transfer was not initialized");
                    currentOut.flush();
                    currentOut.close();
                    currentOut = null;
                    if (receivedChunks != expectedChunks) throw new IOException("Incomplete chunks " + receivedChunks + "/" + expectedChunks);
                    if (expectedBytes >= 0 && receivedBytes != expectedBytes) throw new IOException("Byte count mismatch " + receivedBytes + "/" + expectedBytes);
                    if (receivedBytes <= 0 || !looksLikeImageHeader(currentHeader, currentHeaderLen, currentMime)) throw new IOException("Image validation failed");
                    outputStore.finalizePending(currentPendingOutput);

                    String dbName = currentTarget.dbPath;
                    db.markDone(id, dbName, receivedBytes, 200, currentMime);
                    String finishedUrl = currentItem == null ? null : currentItem.url;
                    String finishedMode = currentExtractMode;
                    boolean finishedWasFast = currentWasFastPath;
                    long elapsed = System.currentTimeMillis() - currentStartedAt;
                    currentPendingOutput = null;
                    AppLog.d(DownloadService.this, "TRANSFER done id=" + id + " bytes=" + receivedBytes + " elapsed_ms=" + elapsed + " file=" + dbName + " mode=" + finishedMode + " adaptive_window=" + adaptivePrefetch);
                    if (challengeAutoAttempts > 0) {
                        postChallengeSuccessStreak++;
                        if (postChallengeSuccessStreak >= POST_CHALLENGE_STABLE_SUCCESSES) {
                            AppLog.d(DownloadService.this, "AUTH auto-recovery stabilized after " + postChallengeSuccessStreak + " successful files; reset retry counter");
                            challengeAutoAttempts = 0;
                            postChallengeSuccessStreak = 0;
                            prefs().edit().putInt("challenge_auto_attempts", 0).apply();
                        }
                    }
                    fastSessionReady = true;
                    markNetworkCompletion();
                    if (finishedWasFast) adaptiveOnFastSuccess(finishedMode);
                    prefs().edit().putString("browser_stage", "DONE / PREFETCHING").apply();
                    cleanupPrefetch(finishedUrl);
                    clearCurrentAfterSuccess();
                    main.post(() -> {
                        prefetchUpcoming();
                        maybeUpdateNotification();
                        if (pauseAfterCurrent || prefs().getBoolean("pause_requested", false)) {
                            stopWithReason("PAUSED BY USER", "-", false);
                        } else {
                            main.postDelayed(DownloadService.this::startNext, BETWEEN_ITEMS_MS);
                        }
                    });
                } catch (Throwable t) {
                    AppLog.d(DownloadService.this, "TRANSFER complete failed id=" + id + " " + t);
                    closeCurrentOutLocked();
                    main.post(() -> retryCurrent("Transfer validation/finalize failed: " + t.getMessage(), 0, currentMime));
                }
            }
        }

        @JavascriptInterface public void onExtractFailure(String token, long id, String error) {
            if (!isCurrent(id, token)) return;
            AppLog.d(DownloadService.this, "BROWSER extraction failed id=" + id + " " + error);
            main.post(() -> retryCurrent("Browser extraction failed: " + error, prefs().getInt("browser_last_http", 0), prefs().getString("browser_last_mime", null)));
        }
    }

    private void authRequired(String detail) {
        if (currentItem == null) return;
        long id = currentItem.id;
        String url = currentItem.url;
        resetTransferState(true);
        try { if (webView != null) webView.stopLoading(); } catch (Throwable ignored) {}
        db.returnToPending(id, "Browser verification required. " + detail);
        currentItem = null;
        currentToken = null;
        extractionStarted = false;
        fastFetchInFlight = false;
        currentWasFastPath = false;
        fastSessionReady = false;
        adaptivePrefetch = PREFETCH_MIN;
        adaptiveFastSuccessStreak = 0;
        adaptiveFallbackDebt = 0;
        postChallengeSuccessStreak = 0;
        cautiousUntilWall = System.currentTimeMillis() + AUTH_CAUTION_MS;

        challengeAutoAttempts++;
        prefs().edit().putInt("adaptive_prefetch", adaptivePrefetch)
                .putInt("challenge_auto_attempts", challengeAutoAttempts)
                .putLong("challenge_seen_at", System.currentTimeMillis())
                .putString("auth_target_url", url)
                .putLong("auth_target_id", id)
                .putString("auth_reason", detail)
                .putBoolean("resume_after_auth", true).apply();
        AppLog.d(this, "AUTH_REQUIRED id=" + id + " detail=" + detail + " url=" + url + " auto_attempt=" + challengeAutoAttempts);

        if (challengeAutoAttempts <= CHALLENGE_AUTO_BACKOFF_MS.length) {
            long delay = CHALLENGE_AUTO_BACKOFF_MS[challengeAutoAttempts - 1];
            challengeCooldownActive = true;
            setState("CHALLENGE COOLDOWN — AUTO RETRY", url + " in " + (delay / 1000L) + "s");
            prefs().edit().putString("browser_stage", "CHALLENGE COOLDOWN").apply();
            updateNotification("Verification detected — cooling down; retry in " + (delay / 1000L) + "s");
            AppLog.d(this, "AUTH cooldown scheduled delay_ms=" + delay + " attempt=" + challengeAutoAttempts);
            main.removeCallbacks(challengeAutoRetry);
            main.postDelayed(challengeAutoRetry, delay);
            return;
        }

        challengeCooldownActive = false;
        main.removeCallbacks(challengeAutoRetry);
        AppLog.d(this, "AUTH automatic recovery exhausted; visible verification required url=" + url);
        stopWithReason("AUTH REQUIRED — AUTO OPENING BROWSER", url, false);
        main.postDelayed(() -> launchAuthActivity(url), 450L);
    }

    private void retryCurrent(String error, int code, String mime) {
        if (currentItem == null) return;
        QueueDb.Item item = currentItem;
        resetTransferState(true);
        int r = item.retryCount + 1;
        if (r > 5) {
            db.markFailed(item.id, code, mime, error);
            markTerminalWithoutNetworkSample();
            AppLog.d(this, "RETRY exhausted id=" + item.id + " error=" + error);
        } else {
            long[] backoff = {5_000L, 30_000L, 120_000L, 600_000L, 1_800_000L};
            long delay = backoff[Math.min(r - 1, backoff.length - 1)];
            db.markRetry(item.id, r, delay, code, mime, error);
            AppLog.d(this, "RETRY scheduled id=" + item.id + " attempt=" + r + " delay_ms=" + delay + " error=" + error);
        }
        currentItem = null;
        currentToken = null;
        extractionStarted = false;
        fastFetchInFlight = false;
        currentWasFastPath = false;
        prefs().edit().remove("current_target_url").remove("current_target_id").apply();
        main.postDelayed(this::startNext, BETWEEN_ITEMS_MS);
    }

    private void clearCurrentAfterSuccess() {
        synchronized (transferLock) {
            closeCurrentOutLocked();
            currentPendingOutput = null;
            currentTarget = null;
            currentHeaderLen = 0;
            currentMime = null;
            currentExtractMode = null;
            expectedChunks = 0;
            receivedChunks = 0;
            expectedBytes = 0;
            receivedBytes = 0;
        }
        currentItem = null;
        currentToken = null;
        extractionStarted = false;
        fastFetchInFlight = false;
        currentWasFastPath = false;
        prefs().edit().remove("current_target_url").remove("current_target_id").apply();
    }

    private void resetTransferState(boolean deletePart) {
        synchronized (transferLock) { resetTransferStateLocked(deletePart); }
    }

    private void resetTransferStateLocked(boolean deletePart) {
        closeCurrentOutLocked();
        if (deletePart && currentPendingOutput != null) outputStore.abort(currentPendingOutput);
        currentPendingOutput = null;
        currentTarget = null;
        currentHeaderLen = 0;
        currentMime = null;
        currentExtractMode = null;
        expectedChunks = 0;
        receivedChunks = 0;
        expectedBytes = 0;
        receivedBytes = 0;
    }

    private void closeCurrentOutLocked() {
        if (currentOut != null) {
            try { currentOut.close(); } catch (Exception ignored) {}
            currentOut = null;
        }
    }

    private boolean isCurrent(long id, String token) {
        QueueDb.Item item = currentItem;
        return active && item != null && item.id == id && token != null && token.equals(currentToken);
    }

    private void touchProgress(String stage) {
        lastProgressAt = System.currentTimeMillis();
        if (stage != null) prefs().edit().putString("browser_stage", stage).apply();
    }

    private boolean sameTarget(String observed, String expected) {
        if (observed == null || expected == null) return false;
        int a = observed.indexOf('#'); if (a >= 0) observed = observed.substring(0, a);
        int b = expected.indexOf('#'); if (b >= 0) expected = expected.substring(0, b);
        return observed.equals(expected);
    }

    private void attachWebViewOverlay() {
        if (webView == null || overlayAttached) return;
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            stopWithReason("BACKGROUND OVERLAY PERMISSION REQUIRED", "Enable Draw over other apps, then Start again", true);
            return;
        }
        try {
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    2, 2,
                    Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.x = 0; lp.y = 0; lp.alpha = 0.02f;
            windowManager.addView(webView, lp);
            overlayAttached = true;
            prefs().edit().putString("browser_overlay", "ATTACHED 2x2").apply();
            AppLog.d(this, "BROWSER overlay attached 2x2");
        } catch (Throwable t) {
            AppLog.d(this, "BROWSER overlay attach failed " + t);
            stopWithReason("BACKGROUND OVERLAY ERROR", t.getClass().getSimpleName() + ": " + t.getMessage(), true);
        }
    }

    private void detachWebViewOverlay() {
        if (!overlayAttached || webView == null || windowManager == null) return;
        try { windowManager.removeViewImmediate(webView); } catch (Throwable ignored) {}
        overlayAttached = false;
        prefs().edit().putString("browser_overlay", "DETACHED").apply();
    }

    private boolean isTransferActive() {
        synchronized (transferLock) {
            return currentOut != null || currentPendingOutput != null;
        }
    }

    private void handleNavigationStall(String reason) {
        if (!active || currentItem == null) return;
        stallRekickCount++;
        AppLog.d(this, "WATCHDOG navigation stall id=" + currentItem.id + " count=" + stallRekickCount +
                " reason=" + reason + " webUrl=" + (webView == null ? "-" : webView.getUrl()));
        if (stallRekickCount > MAX_STALL_REKICKS) {
            requestVisibleAuthForCurrent("Repeated browser stall after " + MAX_STALL_REKICKS + " re-kicks: " + reason);
            return;
        }
        restartCurrentNavigation(reason + "-kick" + stallRekickCount);
    }

    private void requestVisibleAuthForCurrent(String detail) {
        if (currentItem == null) return;
        long id = currentItem.id;
        String url = currentItem.url;
        long now = System.currentTimeMillis();
        if (authLaunchInFlight && now - lastAuthLaunchAt < AUTH_LAUNCH_DEBOUNCE_MS) return;
        authLaunchInFlight = true;
        lastAuthLaunchAt = now;
        resetTransferState(true);
        try { if (webView != null) webView.stopLoading(); } catch (Throwable ignored) {}
        db.returnToPending(id, "Visible browser requested after stall. " + detail);
        currentItem = null;
        currentToken = null;
        extractionStarted = false;
        fastFetchInFlight = false;
        currentWasFastPath = false;
        fastSessionReady = false;
        adaptivePrefetch = PREFETCH_MIN;
        cautiousUntilWall = now + AUTH_CAUTION_MS;
        prefs().edit()
                .putString("auth_target_url", url)
                .putLong("auth_target_id", id)
                .putString("auth_reason", detail)
                .putBoolean("resume_after_auth", true)
                .putInt("adaptive_prefetch", PREFETCH_MIN)
                .apply();
        AppLog.d(this, "AUTH AUTO-OPEN requested id=" + id + " reason=" + detail + " url=" + url);
        setState("AUTH REQUIRED — AUTO OPENING BROWSER", url);
        updateNotification("Browser stalled — opening verification browser");
        finishService(true);
        main.postDelayed(() -> launchAuthActivity(url), 450L);
    }

    private void launchAuthActivity(String url) {
        if (url == null || url.isEmpty()) return;
        try {
            Intent i = new Intent(this, AuthActivity.class);
            i.putExtra(AuthActivity.EXTRA_TARGET_URL, url);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(i);
            AppLog.d(this, "AUTH AUTO-OPEN launched url=" + url);
        } catch (Throwable t) {
            AppLog.d(this, "AUTH AUTO-OPEN failed " + t);
        }
    }

    private void restartCurrentNavigation(String reason) {
        if (!active || currentItem == null || webView == null) return;
        resetTransferState(true);
        extractionStarted = false;
        fastFetchInFlight = false;
        currentWasFastPath = false;
        currentToken = UUID.randomUUID().toString();
        attachWebViewOverlay();
        try { webView.onResume(); webView.resumeTimers(); } catch (Throwable ignored) {}
        AppLog.d(this, "BROWSER re-kick id=" + currentItem.id + " reason=" + reason + " url=" + currentItem.url);
        navigateCurrent("re-kick:" + reason);
    }

    private static boolean looksLikeImageHeader(byte[] h, int n, String mime) {
        if (h == null || n < 3) return false;
        // Trust file signatures, not HTTP Content-Type. Some Whiskybase JPEGs are served as
        // application/octet-stream; Cloudflare HTML must never pass this validation.
        if ((h[0]&255)==0xFF && (h[1]&255)==0xD8 && (h[2]&255)==0xFF) return true;
        if (n>=8 && (h[0]&255)==0x89 && h[1]=='P' && h[2]=='N' && h[3]=='G') return true;
        if (h[0]=='G' && h[1]=='I' && h[2]=='F') return true;
        if (n>=12 && h[0]=='R' && h[1]=='I' && h[2]=='F' && h[3]=='F' && h[8]=='W' && h[9]=='E' && h[10]=='B' && h[11]=='P') return true;
        if (n>=12 && h[4]=='f' && h[5]=='t' && h[6]=='y' && h[7]=='p') {
            String brand = new String(h, 8, Math.min(8, n - 8), java.nio.charset.StandardCharsets.US_ASCII).toLowerCase(Locale.US);
            if (brand.contains("avif") || brand.contains("avis")) return true;
        }
        return false;
    }

    private boolean looksLikeVerificationPage(String contentType, String title, String text) {
        String ct = contentType == null ? "" : contentType.toLowerCase(Locale.US);
        if (ct.startsWith("image/")) return false;
        String all = ((title == null ? "" : title) + " " + (text == null ? "" : text)).toLowerCase(Locale.US);
        return all.contains("cloudflare") || all.contains("ray id") || all.contains("보안 확인") ||
                all.contains("잠시만 기다리십시오") || all.contains("security verification") || all.contains("checking your browser");
    }

    private void initEtaAndAdaptive() {
        QueueDb.Stats st = db.stats();
        etaTotal = st.total();
        etaTerminal = st.counts[QueueDb.DONE] + st.counts[QueueDb.SKIPPED] + st.counts[QueueDb.FAILED];
        etaRateIps = Math.max(0.0, prefs().getFloat("eta_rate_ips", 0f));
        synchronized (completionTimes) { completionTimes.clear(); }
        long now = System.currentTimeMillis();
        long authAt = Math.max(prefs().getLong("auth_verified_at", 0L), prefs().getLong("auth_saved_at", 0L));
        if (authAt > 0 && now - authAt < 120_000L) {
            adaptivePrefetch = PREFETCH_MIN;
            cautiousUntilWall = now + AUTH_CAUTION_MS;
        } else {
            adaptivePrefetch = Math.max(PREFETCH_MIN, Math.min(PREFETCH_MAX, prefs().getInt("adaptive_prefetch", PREFETCH_INITIAL)));
            cautiousUntilWall = 0L;
        }
        adaptiveFastSuccessStreak = 0;
        adaptiveFallbackDebt = 0;
        challengeAutoAttempts = prefs().getInt("challenge_auto_attempts", 0);
        if (authAt > 0 && now - authAt < 120_000L) challengeAutoAttempts = 0;
        postChallengeSuccessStreak = 0;
        challengeCooldownActive = false;
        updateEtaPrefs();
        prefs().edit().putInt("adaptive_prefetch", adaptivePrefetch).apply();
    }

    private int effectivePrefetchWindow() {
        if (System.currentTimeMillis() < cautiousUntilWall) return Math.min(2, adaptivePrefetch);
        return Math.max(PREFETCH_MIN, Math.min(PREFETCH_MAX, adaptivePrefetch));
    }

    private void adaptiveOnFallback(String reason) {
        adaptiveFastSuccessStreak = 0;
        adaptiveFallbackDebt++;
        if (adaptiveFallbackDebt >= 2 && adaptivePrefetch > PREFETCH_MIN) {
            adaptivePrefetch--;
            adaptiveFallbackDebt = 0;
            AppLog.d(this, "ADAPT prefetch decrease -> " + adaptivePrefetch + " reason=" + reason);
        }
        prefs().edit().putInt("adaptive_prefetch", adaptivePrefetch).apply();
    }

    private void adaptiveOnFastSuccess(String mode) {
        if (adaptiveFallbackDebt > 0) adaptiveFallbackDebt--;
        adaptiveFastSuccessStreak += (mode != null && mode.contains("prefetch-cache-hit")) ? 2 : 1;
        if (System.currentTimeMillis() >= cautiousUntilWall && adaptiveFastSuccessStreak >= 16 && adaptivePrefetch < PREFETCH_MAX) {
            adaptivePrefetch++;
            adaptiveFastSuccessStreak = 0;
            AppLog.d(this, "ADAPT prefetch increase -> " + adaptivePrefetch + " mode=" + mode);
        }
        prefs().edit().putInt("adaptive_prefetch", adaptivePrefetch).apply();
    }

    private void markNetworkCompletion() {
        synchronized (completionTimes) {
            etaTerminal++;
            long now = SystemClock.elapsedRealtime();
            completionTimes.addLast(now);
            while (completionTimes.size() > ETA_MAX_SAMPLES) completionTimes.removeFirst();
            while (completionTimes.size() > 2 && now - completionTimes.peekFirst() > ETA_WINDOW_MS) completionTimes.removeFirst();
            if (completionTimes.size() >= 3) {
                long first = completionTimes.peekFirst();
                long last = completionTimes.peekLast();
                if (last > first) {
                    double r = (completionTimes.size() - 1) * 1000.0 / (last - first);
                    if (r > 0 && Double.isFinite(r)) etaRateIps = r;
                }
            }
        }
        updateEtaPrefs();
    }

    private void markTerminalWithoutNetworkSample() {
        synchronized (completionTimes) { etaTerminal++; }
        updateEtaPrefs();
    }

    private void updateEtaPrefs() {
        long remaining = Math.max(0L, etaTotal - etaTerminal);
        long etaSeconds = etaRateIps > 0.0001 ? (long)Math.ceil(remaining / etaRateIps) : -1L;
        long finish = etaSeconds >= 0 ? System.currentTimeMillis() + etaSeconds * 1000L : 0L;
        prefs().edit()
                .putFloat("eta_rate_ips", (float)etaRateIps)
                .putLong("eta_seconds", etaSeconds)
                .putLong("eta_finish_at", finish)
                .putLong("eta_remaining", remaining)
                .apply();
    }

    private void migrateLegacyFiles() {
        if (prefs().getBoolean("legacy_migrated_v06", false)) return;
        File base = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File legacyRoot = base == null ? null : new File(base, "WhiskyCrawler");
        if (legacyRoot == null || !legacyRoot.exists()) {
            prefs().edit().putBoolean("legacy_migrated_v06", true).apply();
            return;
        }
        long moved = 0L;
        boolean hadFailure = false;
        prefs().edit().putString("service_status", "MIGRATING LEGACY FILES").putString("browser_stage", "MIGRATING v0.1-v0.5 OUTPUT").apply();
        while (active) {
            List<QueueDb.DoneItem> batch = db.legacyDoneBatch(250);
            if (batch.isEmpty()) break;
            for (QueueDb.DoneItem d : batch) {
                try {
                    File src = new File(legacyRoot, d.filename);
                    SharedOutputStore.Target target = outputStore.targetFor(d.url);
                    SharedOutputStore.Existing out = outputStore.findExisting(target);
                    if (out == null && src.isFile() && src.length() > 0) {
                        out = outputStore.copyLegacyFile(src, target, d.mime);
                    }
                    if (out != null) {
                        db.updateDoneLocation(d.id, out.dbPath, out.size, out.mime);
                        if (src.isFile()) { //noinspection ResultOfMethodCallIgnored
                            src.delete();
                        }
                        moved++;
                    } else {
                        AppLog.d(this, "MIGRATE missing legacy file id=" + d.id + " old=" + d.filename);
                        // Keep the DB row as-is; do not loop forever on a missing source.
                        db.updateDoneLocation(d.id, d.filename, d.fileSize, d.mime);
                        hadFailure = true;
                    }
                } catch (Throwable t) {
                    hadFailure = true;
                    AppLog.d(this, "MIGRATE failed id=" + d.id + " " + t);
                    break;
                }
            }
            if (hadFailure || batch.size() < 250) break;
        }
        if (!hadFailure) prefs().edit().putBoolean("legacy_migrated_v06", true).apply();
        AppLog.d(this, "MIGRATE legacy complete moved=" + moved + " success=" + (!hadFailure));
    }

    private SharedPreferences prefs() { return getSharedPreferences("state", MODE_PRIVATE); }

    private void setState(String state, String current) {
        prefs().edit().putString("service_status", state)
                .putString("current", current == null ? "-" : current)
                .putLong("last_state_at", System.currentTimeMillis()).apply();
    }

    private void stopWithReason(String state, String current, boolean returnCurrentToPending) {
        if (!active && currentItem == null) {
            setState(state, current);
            stopSelf();
            return;
        }
        if (returnCurrentToPending && currentItem != null) {
            db.returnToPending(currentItem.id, state);
        }
        AppLog.d(this, "SERVICE stop state=" + state + " current=" + current);
        setState(state, current);
        finishService(true);
    }

    private void finishService(boolean stopWebLoading) {
        active = false;
        fastSessionReady = false;
        fastFetchInFlight = false;
        currentWasFastPath = false;
        main.removeCallbacks(watchdog);
        main.removeCallbacks(challengeAutoRetry);
        challengeCooldownActive = false;
        if (stopWebLoading && webView != null) {
            try { webView.stopLoading(); } catch (Exception ignored) {}
        }
        resetTransferState(true);
        detachWebViewOverlay();
        releaseWakeLock();
        CellularNetwork.unbindProcess(this);
        stopForeground(STOP_FOREGROUND_DETACH);
        stopSelf();
    }

    private void acquireWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) return;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WhiskyDownloader:WebViewDirect");
        wakeLock.setReferenceCounted(false);
        wakeLock.acquire();
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (Exception ignored) {}
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Image downloads", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Adaptive cellular WebView queue with shared Downloads storage");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    private void startAsForeground(String text) {
        Notification n = notification(text);
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        else startForeground(NOTIFICATION_ID, n);
    }

    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent pause = new Intent(this, DownloadService.class).setAction(ACTION_PAUSE);
        PendingIntent pPause = PendingIntent.getService(this, 1, pause, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("Whisky LTE Downloader v0.8")
                .setContentText(text)
                .setContentIntent(pi)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "Pause", pPause).build())
                .build();
    }

    private void maybeUpdateNotification() {
        long now = System.currentTimeMillis();
        if (now - lastNotificationAt < 2_000L) return;
        lastNotificationAt = now;
        updateNotification(null);
    }

    private void updateNotification(String override) {
        String text = override;
        if (text == null) {
            QueueDb.Stats s = db.stats();
            double rate = prefs().getFloat("eta_rate_ips", 0f);
            long eta = prefs().getLong("eta_seconds", -1L);
            text = String.format(Locale.US, "%,d / %,d · %.2f img/s · ETA %s", s.counts[QueueDb.DONE], s.total(), rate, formatEtaCompact(eta));
        }
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIFICATION_ID, notification(text));
    }

    private static String formatEtaCompact(long sec) {
        if (sec < 0) return "warming";
        long d = sec / 86400L; sec %= 86400L;
        long h = sec / 3600L; sec %= 3600L;
        long m = sec / 60L;
        if (d > 0) return d + "d " + h + "h";
        if (h > 0) return h + "h " + m + "m";
        return m + "m";
    }

    private static String humanBytes(long b) {
        double v=b; String[] u={"B","KB","MB","GB","TB"}; int i=0;
        while(v>=1024 && i<u.length-1){v/=1024;i++;}
        return String.format(Locale.US,"%.1f %s",v,u[i]);
    }

    private static String trim(String s, int n) { return s == null || s.length() <= n ? s : s.substring(0, n); }
    private static String nullToDash(String s) { return s == null || s.trim().isEmpty() ? "-" : s; }

    @Override public void onTimeout(int startId, int fgsType) {
        AppLog.d(this, "SERVICE Android FGS timeout");
        stopWithReason("PAUSED BY ANDROID FGS TIMEOUT", "-", true);
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onTaskRemoved(Intent rootIntent) {
        AppLog.d(this, "SERVICE task removed; foreground service remains active=" + active);
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onDestroy() {
        active = false;
        main.removeCallbacks(watchdog);
        main.removeCallbacks(challengeAutoRetry);
        challengeCooldownActive = false;
        resetTransferState(true);
        detachWebViewOverlay();
        releaseWakeLock();
        CellularNetwork.unbindProcess(this);
        if (webView != null) {
            WebView v = webView;
            webView = null;
            main.post(() -> {
                try { v.stopLoading(); v.removeJavascriptInterface("AndroidBridge"); v.destroy(); } catch (Exception ignored) {}
            });
        }
        if (db != null) db.close();
        networkWorker.shutdownNow();
        CookieManager.getInstance().flush();
        AppLog.d(this, "SERVICE v0.8 destroyed");
        super.onDestroy();
    }
}
