package com.sinsa.whiskydownloader;

import android.content.Context;
import android.os.Environment;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class AppLog {
    private static final Object LOCK = new Object();
    private static final long MAX_BYTES = 5L * 1024 * 1024;
    private static final ExecutorService IO = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "WhiskyLogIO");
        t.setDaemon(true);
        return t;
    });
    private AppLog() {}

    public static File file(Context c) {
        File base = c.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
        if (base == null) base = c.getFilesDir();
        File dir = new File(base, "WhiskyCrawlerLogs");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        return new File(dir, "downloader.log");
    }

    public static void d(Context c, String msg) {
        final Context app = c.getApplicationContext();
        final String safe = sanitize(msg);
        // Logging must never block WebView callbacks or the image-transfer hot path.
        IO.execute(() -> {
            synchronized (LOCK) {
                try {
                    File f = file(app);
                    if (f.length() > MAX_BYTES) rotate(f);
                    String ts = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
                    String line = ts + "  " + safe + "\n";
                    try (FileOutputStream out = new FileOutputStream(f, true)) {
                        out.write(line.getBytes(StandardCharsets.UTF_8));
                    }
                } catch (Exception ignored) {}
            }
        });
    }

    private static void rotate(File f) {
        File old = new File(f.getParentFile(), "downloader.log.1");
        //noinspection ResultOfMethodCallIgnored
        old.delete();
        //noinspection ResultOfMethodCallIgnored
        f.renameTo(old);
    }

    private static String sanitize(String s) {
        if (s == null) return "";
        return s.replace('\r', ' ').replace('\n', ' ');
    }

    public static String tail(Context c, int maxLines) {
        synchronized (LOCK) {
            File f = file(c);
            if (!f.exists()) return "No log entries yet.";
            try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
                List<String> ring = new ArrayList<>();
                String line;
                while ((line = br.readLine()) != null) {
                    ring.add(line);
                    if (ring.size() > maxLines) ring.remove(0);
                }
                StringBuilder sb = new StringBuilder();
                for (String x : ring) sb.append(x).append('\n');
                return sb.toString();
            } catch (Exception e) {
                return "Could not read log: " + e.getMessage();
            }
        }
    }
}
