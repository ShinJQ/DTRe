package com.sinsa.whiskydownloader;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public final class QueueDb extends SQLiteOpenHelper {
    public static final int PENDING = 0;
    public static final int PROCESSING = 1;
    public static final int DONE = 2;
    public static final int SKIPPED = 3;
    public static final int RETRY = 4;
    public static final int FAILED = 5;

    private static final String DB_NAME = "download_queue.db";
    private static final int DB_VERSION = 1;

    public QueueDb(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE queue (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "url TEXT NOT NULL UNIQUE," +
                "status INTEGER NOT NULL DEFAULT 0," +
                "retry_count INTEGER NOT NULL DEFAULT 0," +
                "next_retry_at INTEGER NOT NULL DEFAULT 0," +
                "filename TEXT," +
                "file_size INTEGER NOT NULL DEFAULT 0," +
                "http_status INTEGER," +
                "mime_type TEXT," +
                "last_error TEXT," +
                "updated_at INTEGER NOT NULL DEFAULT 0" +
                ")");
        db.execSQL("CREATE INDEX idx_queue_status_retry ON queue(status, next_retry_at, id)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

    public synchronized long importUrls(InputStream input) throws IOException {
        SQLiteDatabase db = getWritableDatabase();
        long inserted = 0;
        BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8), 64 * 1024);
        String line;
        int batch = 0;
        db.beginTransaction();
        try {
            while ((line = reader.readLine()) != null) {
                String url = line.trim();
                if (url.isEmpty() || url.startsWith("#")) continue;
                ContentValues cv = new ContentValues();
                cv.put("url", url);
                cv.put("updated_at", System.currentTimeMillis());
                long row = db.insertWithOnConflict("queue", null, cv, SQLiteDatabase.CONFLICT_IGNORE);
                if (row != -1) inserted++;
                batch++;
                if (batch >= 1000) {
                    db.setTransactionSuccessful();
                    db.endTransaction();
                    db.beginTransaction();
                    batch = 0;
                }
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
            reader.close();
        }
        return inserted;
    }

    public synchronized void recoverInterrupted() {
        ContentValues cv = new ContentValues();
        cv.put("status", PENDING);
        cv.put("updated_at", System.currentTimeMillis());
        getWritableDatabase().update("queue", cv, "status=?", new String[]{String.valueOf(PROCESSING)});
    }

    public synchronized Item claimNext() {
        long now = System.currentTimeMillis();
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try (Cursor c = db.rawQuery(
                "SELECT id,url,retry_count FROM queue WHERE status=? OR (status=? AND next_retry_at<=?) ORDER BY id LIMIT 1",
                new String[]{String.valueOf(PENDING), String.valueOf(RETRY), String.valueOf(now)})) {
            if (!c.moveToFirst()) return null;
            long id = c.getLong(0);
            String url = c.getString(1);
            int retries = c.getInt(2);
            ContentValues cv = new ContentValues();
            cv.put("status", PROCESSING);
            cv.put("updated_at", now);
            int n = db.update("queue", cv, "id=? AND status IN (?,?)",
                    new String[]{String.valueOf(id), String.valueOf(PENDING), String.valueOf(RETRY)});
            if (n != 1) return null;
            db.setTransactionSuccessful();
            return new Item(id, url, retries);
        } finally {
            db.endTransaction();
        }
    }

    /** Claim one exact URL for a targeted recovery. Unlike claimNext(), this does not let an older
     * due RETRY row hijack a challenge retry that belongs to another URL. */
    public synchronized Item claimByUrl(String url) {
        if (url == null || url.trim().isEmpty()) return null;
        long now = System.currentTimeMillis();
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try (Cursor c = db.rawQuery(
                "SELECT id,url,retry_count FROM queue WHERE url=? AND status IN (?,?) LIMIT 1",
                new String[]{url, String.valueOf(PENDING), String.valueOf(RETRY)})) {
            if (!c.moveToFirst()) return null;
            long id = c.getLong(0);
            String foundUrl = c.getString(1);
            int retries = c.getInt(2);
            ContentValues cv = new ContentValues();
            cv.put("status", PROCESSING);
            cv.put("updated_at", now);
            int n = db.update("queue", cv, "id=? AND status IN (?,?)",
                    new String[]{String.valueOf(id), String.valueOf(PENDING), String.valueOf(RETRY)});
            if (n != 1) return null;
            db.setTransactionSuccessful();
            return new Item(id, foundUrl, retries);
        } finally {
            db.endTransaction();
        }
    }

    public synchronized void markDone(long id, String filename, long size, int httpStatus, String mime) {
        ContentValues cv = base(DONE, httpStatus, mime, null);
        cv.put("filename", filename);
        cv.put("file_size", size);
        getWritableDatabase().update("queue", cv, "id=?", new String[]{String.valueOf(id)});
    }

    public synchronized void markSkipped(long id, int httpStatus, String mime, String error) {
        getWritableDatabase().update("queue", base(SKIPPED, httpStatus, mime, error), "id=?", new String[]{String.valueOf(id)});
    }

    public synchronized void markFailed(long id, int httpStatus, String mime, String error) {
        getWritableDatabase().update("queue", base(FAILED, httpStatus, mime, error), "id=?", new String[]{String.valueOf(id)});
    }

    public synchronized void markRetry(long id, int retryCount, long delayMs, int httpStatus, String mime, String error) {
        ContentValues cv = base(RETRY, httpStatus, mime, error);
        cv.put("retry_count", retryCount);
        cv.put("next_retry_at", System.currentTimeMillis() + delayMs);
        getWritableDatabase().update("queue", cv, "id=?", new String[]{String.valueOf(id)});
    }

    public synchronized void returnToPending(long id, String error) {
        ContentValues cv = base(PENDING, 0, null, error);
        getWritableDatabase().update("queue", cv, "id=?", new String[]{String.valueOf(id)});
    }

    private ContentValues base(int status, int httpStatus, String mime, String error) {
        ContentValues cv = new ContentValues();
        cv.put("status", status);
        cv.put("http_status", httpStatus);
        if (mime != null) cv.put("mime_type", mime); else cv.putNull("mime_type");
        if (error != null) cv.put("last_error", trim(error, 1000)); else cv.putNull("last_error");
        cv.put("updated_at", System.currentTimeMillis());
        return cv;
    }

    public synchronized Stats stats() {
        long[] counts = new long[6];
        try (Cursor c = getReadableDatabase().rawQuery("SELECT status,COUNT(*) FROM queue GROUP BY status", null)) {
            while (c.moveToNext()) {
                int s = c.getInt(0);
                if (s >= 0 && s < counts.length) counts[s] = c.getLong(1);
            }
        }
        long bytes = 0;
        try (Cursor c = getReadableDatabase().rawQuery("SELECT COALESCE(SUM(file_size),0) FROM queue WHERE status=?", new String[]{String.valueOf(DONE)})) {
            if (c.moveToFirst()) bytes = c.getLong(0);
        }
        return new Stats(counts, bytes);
    }


    public synchronized List<Item> peekNext(int limit) {
        long now = System.currentTimeMillis();
        ArrayList<Item> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,url,retry_count FROM queue WHERE status=? OR (status=? AND next_retry_at<=?) ORDER BY id LIMIT ?",
                new String[]{String.valueOf(PENDING), String.valueOf(RETRY), String.valueOf(now), String.valueOf(Math.max(1, limit))})) {
            while (c.moveToNext()) {
                out.add(new Item(c.getLong(0), c.getString(1), c.getInt(2)));
            }
        }
        return out;
    }


    public synchronized List<DoneItem> legacyDoneBatch(int limit) {
        ArrayList<DoneItem> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,url,filename,file_size,mime_type FROM queue WHERE status=? AND filename IS NOT NULL AND filename NOT LIKE ? ORDER BY id LIMIT ?",
                new String[]{String.valueOf(DONE), "Download/WhiskyCrawler/%", String.valueOf(Math.max(1, limit))})) {
            while (c.moveToNext()) {
                out.add(new DoneItem(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3), c.isNull(4) ? null : c.getString(4)));
            }
        }
        return out;
    }

    public synchronized void updateDoneLocation(long id, String filename, long size, String mime) {
        ContentValues cv = new ContentValues();
        cv.put("filename", filename);
        cv.put("file_size", size);
        if (mime != null) cv.put("mime_type", mime);
        cv.put("updated_at", System.currentTimeMillis());
        getWritableDatabase().update("queue", cv, "id=? AND status=?",
                new String[]{String.valueOf(id), String.valueOf(DONE)});
    }

    public synchronized String firstPendingUrlOrNull() {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT url FROM queue WHERE status IN (?,?) ORDER BY id LIMIT 1",
                new String[]{String.valueOf(PENDING), String.valueOf(RETRY)})) {
            return c.moveToFirst() ? c.getString(0) : null;
        }
    }

    public synchronized String latestError() {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,http_status,mime_type,last_error FROM queue WHERE last_error IS NOT NULL ORDER BY updated_at DESC LIMIT 1", null)) {
            if (!c.moveToFirst()) return "-";
            return "#" + c.getLong(0) + " HTTP=" + (c.isNull(1) ? "-" : c.getInt(1)) +
                    " MIME=" + (c.isNull(2) ? "-" : c.getString(2)) + " " + c.getString(3);
        }
    }

    public synchronized void clearAll() {
        getWritableDatabase().delete("queue", null, null);
    }

    public synchronized void retryFailedAndSkipped() {
        ContentValues cv = new ContentValues();
        cv.put("status", PENDING);
        cv.put("retry_count", 0);
        cv.put("next_retry_at", 0);
        cv.put("updated_at", System.currentTimeMillis());
        getWritableDatabase().update("queue", cv, "status IN (?,?)",
                new String[]{String.valueOf(FAILED), String.valueOf(SKIPPED)});
    }

    private static String trim(String s, int n) { return s == null || s.length() <= n ? s : s.substring(0, n); }

    public static final class Item {
        public final long id;
        public final String url;
        public final int retryCount;
        Item(long id, String url, int retryCount) { this.id = id; this.url = url; this.retryCount = retryCount; }
    }


    public static final class DoneItem {
        public final long id;
        public final String url;
        public final String filename;
        public final long fileSize;
        public final String mime;
        DoneItem(long id, String url, String filename, long fileSize, String mime) {
            this.id = id; this.url = url; this.filename = filename; this.fileSize = fileSize; this.mime = mime;
        }
    }

    public static final class Stats {
        public final long[] counts;
        public final long bytes;
        Stats(long[] counts, long bytes) { this.counts = counts; this.bytes = bytes; }
        public long total() { long t=0; for(long v:counts)t+=v; return t; }
    }
}
