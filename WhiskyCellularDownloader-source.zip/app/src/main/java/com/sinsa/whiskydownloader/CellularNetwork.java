package com.sinsa.whiskydownloader;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public final class CellularNetwork {
    private CellularNetwork() {}

    public static Network await(Context context, long timeoutSeconds) throws InterruptedException {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkRequest request = new NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build();
        CountDownLatch latch = new CountDownLatch(1);
        final Network[] result = new Network[1];
        ConnectivityManager.NetworkCallback callback = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network network) {
                result[0] = network;
                latch.countDown();
            }
        };
        cm.requestNetwork(request, callback);
        try {
            latch.await(timeoutSeconds, TimeUnit.SECONDS);
            return result[0];
        } finally {
            try { cm.unregisterNetworkCallback(callback); } catch (Exception ignored) {}
        }
    }

    public static Network bindProcess(Context context, long timeoutSeconds) throws InterruptedException {
        Network n = await(context, timeoutSeconds);
        if (n != null) {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            cm.bindProcessToNetwork(n);
        }
        return n;
    }

    public static void unbindProcess(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        cm.bindProcessToNetwork(null);
    }
}
