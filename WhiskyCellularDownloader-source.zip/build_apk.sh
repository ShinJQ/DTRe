#!/usr/bin/env bash
set -euo pipefail
if command -v ./gradlew >/dev/null 2>&1; then
  ./gradlew assembleDebug
elif command -v gradle >/dev/null 2>&1; then
  gradle assembleDebug
else
  echo "Gradle wrapper/system Gradle not found. Open the project in Android Studio, sync, then Build > Build APK(s)." >&2
  exit 2
fi
