# Whisky LTE Downloader v0.4

Android sideload build for a very large queue of protected direct-image URLs, using a **single persistent WebView/Chromium session**.

## What changed from v0.3

Field logs from v0.3 showed two distinct issues:

1. the off-screen service-owned WebView could stop progressing when the app moved to the background;
2. late WebView callbacks from the previous URL could arrive after the next queue item had already been claimed, which could associate the wrong displayed image with the next queue ID.

v0.4 addresses both.

### Background execution

While downloading, the crawler WebView is attached to a tiny 2×2 px, non-interactive `TYPE_APPLICATION_OVERLAY` window. This keeps the WebView attached to a real Android Window while the main activity is in the background. A foreground service and partial wake lock remain active.

The user must grant **Draw over other apps / Appear on top** permission before starting the crawler.

A watchdog runs every 5 seconds. If the current browser job produces no progress callback for 15 seconds, the current navigation is re-kicked with a new job token. If byte extraction itself stalls, that URL is put through the normal retry path.

### Strict URL/job matching

Every queue item receives a unique token. v0.4 additionally verifies that:

- `onPageStarted` / `onPageFinished` refer to the current queued URL;
- the WebView's current URL matches the current queued URL before DOM inspection;
- JavaScript reports `location.href` matching the current queued URL;
- for an image document, the loaded `img.currentSrc` also matches the current queued URL;
- extraction re-checks `location.href` before reading bytes.

Late callbacks from a previous image are logged as `stale ... ignored` and cannot mark the next item DONE.

## Download flow

1. Import one direct image URL per line into SQLite.
2. Open the first pending URL in the visible authentication browser and wait until the real image is displayed.
3. Return to the app.
4. Tap **Enable background WebView overlay** and grant Android's overlay permission.
5. Tap **Start / Resume WebView-direct on cellular**.
6. The service binds the process to cellular, attaches the tiny crawler WebView overlay, and consumes the SQLite queue.
7. Each image is read from the same Chromium session/cache and written to `.part` before validation and atomic rename.

## Queue safety

Statuses are stored per URL: PENDING, PROCESSING, DONE, SKIPPED, RETRY, FAILED. Stale PROCESSING rows are recovered on service creation. The service now returns `START_STICKY`, so Android may recreate it after process pressure; interrupted jobs are reclaimed from SQLite.

## Output

Files are sharded in groups of 5,000 under:

`Android/data/com.sinsa.whiskydownloader/files/Pictures/WhiskyCrawler/`

## Diagnostics

The rotating diagnostic log records browser navigation, stale callbacks, watchdog events, extraction mode, transfer progress, retries and service lifecycle events.

## Signing note

v0.4 introduces a project-local **test/debug signing key** so future CI builds use the same signature and can update in place while preserving the SQLite queue. This key is intentionally only for this sideload/debug app and is not suitable for production distribution.

Because v0.3 was built on an ephemeral GitHub runner debug key, installing v0.4 over v0.3 may require uninstalling v0.3 once. After v0.4, future builds that retain this test key should update normally.

## Build

- compileSdk 35
- targetSdk 34
- Java 17
- Android Gradle Plugin 8.6.1
- versionCode 4 / versionName 0.4.0

The existing DTRe workflow can build this source ZIP when uploaded as `WhiskyCellularDownloader-source.zip`.
